package com.colortuner

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.WindowManager
import kotlin.math.*

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var overlayView: View? = null
    private val CHANNEL_ID = "colortuner_overlay"
    private val NOTIF_ID   = 1

    companion object {
        const val ACTION_STOP   = "com.colortuner.STOP_OVERLAY"
        const val ACTION_UPDATE = "com.colortuner.UPDATE_OVERLAY"

        fun start(context: Context)  {
            context.startForegroundService(Intent(context, OverlayService::class.java))
        }
        fun stop(context: Context)   {
            context.startService(Intent(context, OverlayService::class.java).apply { action = ACTION_STOP })
        }
        fun update(context: Context) {
            context.startService(Intent(context, OverlayService::class.java).apply { action = ACTION_UPDATE })
        }

        // ── Color matrix math (shared with MainActivity) ──────────────────

        fun buildColorMatrix(
            kelvin: Int,
            saturation: Float,   // 0..1
            gamma: Float,        // e.g. 1.0 = neutral
            redScale: Float,     // 0..1
            greenScale: Float,
            blueScale: Float
        ): ColorMatrix {
            // 1. Kelvin → RGB multipliers (Tanner Helland approximation)
            val (kr, kg, kb) = kelvinToRgb(kelvin)

            // 2. Apply gamma: approximate with per-channel LUT baked into a
            //    piecewise linear scale. Android's ColorMatrix is linear so we
            //    encode gamma as a brightness scalar per channel using the
            //    midpoint (128/255) as the reference:
            //    scale = (0.5^gamma / 0.5) = 2^(1-gamma)
            //    This gives exact result at 0 and 1, and correct midtone shift.
            val gScale = 2f.pow(1f - gamma)

            // 3. Per-channel final scale = kelvin * rgb * gamma
            val fr = (kr * redScale   * gScale).coerceIn(0f, 2f)
            val fg = (kg * greenScale * gScale).coerceIn(0f, 2f)
            val fb = (kb * blueScale  * gScale).coerceIn(0f, 2f)

            // 4. Saturation matrix (Rec.709 luminance weights)
            val s  = saturation
            val lr = 0.2126f; val lg = 0.7152f; val lb = 0.0722f
            val sr = (1 - s) * lr; val sg = (1 - s) * lg; val sb = (1 - s) * lb

            // Saturation matrix (row-major, Android ColorMatrix order):
            // [ sr+s  sg    sb    0  0 ]   R row
            // [ sr    sg+s  sb    0  0 ]   G row
            // [ sr    sg    sb+s  0  0 ]   B row
            // [ 0     0     0     1  0 ]   A row
            val sat = ColorMatrix(floatArrayOf(
                sr + s, sg,     sb,     0f, 0f,
                sr,     sg + s, sb,     0f, 0f,
                sr,     sg,     sb + s, 0f, 0f,
                0f,     0f,     0f,     1f, 0f
            ))

            // 5. Scale matrix (applies kelvin + rgb + gamma)
            val scale = ColorMatrix(floatArrayOf(
                fr, 0f, 0f, 0f, 0f,
                0f, fg, 0f, 0f, 0f,
                0f, 0f, fb, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            ))

            // 6. Compose: scale * sat (apply saturation first, then scale)
            scale.preConcat(sat)
            return scale
        }

        private fun kelvinToRgb(kelvin: Int): Triple<Float, Float, Float> {
            val temp = kelvin / 100.0
            val r: Float
            val g: Float
            val b: Float

            r = if (temp <= 66) 1f
            else (329.698727446 * (temp - 60).pow(-0.1332047592)).coerceIn(0.0, 255.0).toFloat() / 255f

            g = if (temp <= 66)
                (99.4708025861 * ln(temp) - 161.1195681661).coerceIn(0.0, 255.0).toFloat() / 255f
            else
                (288.1221695283 * (temp - 60).pow(-0.0755148492)).coerceIn(0.0, 255.0).toFloat() / 255f

            b = when {
                temp >= 66 -> 1f
                temp <= 19 -> 0f
                else -> (138.5177312231 * ln(temp - 10) - 305.0447927307).coerceIn(0.0, 255.0).toFloat() / 255f
            }

            return Triple(r, g, b)
        }
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                removeOverlay()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_UPDATE -> {
                updateOverlay()
                return START_STICKY
            }
        }
        // Initial start
        startForeground(NOTIF_ID, buildNotification())
        addOverlay()
        return START_STICKY
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ── Overlay management ────────────────────────────────────────────────

    private fun addOverlay() {
        if (overlayView != null) { updateOverlay(); return }

        val view = object : View(this) {
            override fun onDraw(canvas: Canvas) {
                drawColorFilter(canvas)
            }
        }
        view.setLayerType(View.LAYER_TYPE_SOFTWARE, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        )

        try {
            wm.addView(view, params)
            overlayView = view
            Log.d("ColorTuner", "Overlay added")
        } catch (e: Exception) {
            Log.e("ColorTuner", "Failed to add overlay: ${e.message}")
        }
    }

    private fun updateOverlay() {
        val v = overlayView ?: run { addOverlay(); return }
        v.invalidate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification())
    }

    // Draw the color filter as a multiply-blended tinted rect.
    // MULTIPLY mode: output = src * dst, so white (1,1,1) = no change,
    // tinted color scales each channel of whatever is beneath.
    // We derive tint color from the current color matrix diagonal.
    private fun drawColorFilter(canvas: Canvas) {
        val prefs  = getSharedPreferences("colortuner", Context.MODE_PRIVATE)
        val kelvin = prefs.getInt("kelvin", 6500)
        val sat    = prefs.getInt("seekSat", 100) / 100f
        val gamma  = prefs.getFloat("gamma", 1f)
        val red    = prefs.getInt("seekRed",   100) / 100f
        val green  = prefs.getInt("seekGreen", 100) / 100f
        val blue   = prefs.getInt("seekBlue",  100) / 100f

        val matrix = buildColorMatrix(kelvin, sat, gamma, red, green, blue)
        val arr = FloatArray(20)
        matrix.getArray().copyInto(arr)

        // Extract effective RGB multipliers from matrix diagonal (indices 0, 6, 12)
        // These are the per-channel scale factors for neutral (white) input
        val rScale = arr[0].coerceIn(0f, 1f)
        val gScale = arr[6].coerceIn(0f, 1f)
        val bScale = arr[12].coerceIn(0f, 1f)

        // Convert to 0-255 color components
        val r = (rScale * 255).toInt()
        val g = (gScale * 255).toInt()
        val b = (bScale * 255).toInt()

        val paint = Paint().apply {
            color = android.graphics.Color.rgb(r, g, b)
            xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.MULTIPLY)
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }

    private fun removeOverlay() {
        overlayView?.let {
            try { wm.removeView(it) } catch (e: Exception) { /* already removed */ }
            overlayView = null
        }
    }

    // ── Matrix from prefs ─────────────────────────────────────────────────

    private fun currentMatrix(): ColorMatrix {
        val prefs = getSharedPreferences("colortuner", Context.MODE_PRIVATE)
        val kelvin = prefs.getInt("kelvin", 6500)
        val sat    = prefs.getInt("seekSat", 100) / 100f
        val gamma  = prefs.getFloat("gamma", 1f)
        val red    = prefs.getInt("seekRed",   100) / 100f
        val green  = prefs.getInt("seekGreen", 100) / 100f
        val blue   = prefs.getInt("seekBlue",  100) / 100f
        return buildColorMatrix(kelvin, sat, gamma, red, green, blue)
    }

    // ── Notification ──────────────────────────────────────────────────────

    private fun buildNotification(): Notification {
        val prefs  = getSharedPreferences("colortuner", Context.MODE_PRIVATE)
        val kelvin = prefs.getInt("kelvin", 6500)
        val sat    = prefs.getInt("seekSat", 100)
        val gamma  = prefs.getFloat("gamma", 1f)

        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, OverlayService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE)

        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Color Tuner active")
            .setContentText("${kelvin}K  •  sat $sat  •  \u03b3${"%.2f".format(gamma)}")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", stopIntent).build())
            .build()
    }

    private fun createNotificationChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Color Tuner Overlay",
            NotificationManager.IMPORTANCE_LOW).apply {
            description = "Keeps display color correction active"
            setShowBadge(false)
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }
}
