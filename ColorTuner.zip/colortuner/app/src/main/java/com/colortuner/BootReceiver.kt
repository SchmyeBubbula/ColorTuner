package com.colortuner

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.LOCKED_BOOT_COMPLETED") {
            Log.d("ColorTuner", "Boot received — starting watchdog")
            val prefs = context.getSharedPreferences("colortuner", Context.MODE_PRIVATE)
            // Only auto-start if watchdog was running before reboot
            if (prefs.getBoolean("watchdogEnabled", false)) {
                WatchdogService.start(context)
            }
        }
    }
}
