package com.colortuner

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.IBinder
import android.util.Log
import kotlin.math.*
import rikka.shizuku.Shizuku

class ColorService : Service() {

    private val CHANNEL_ID = "colortuner_service"
    private val NOTIF_ID   = 1

    // Reapply when screen turns on (SurfaceFlinger resets on wake sometimes)
    private val screenOnReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_SCREEN_ON) {
                Log.d("ColorTuner", "Screen on — reapplying matrix")
                applyCurrentMatrix()
            }
        }
    }

    companion object {
        const val ACTION_STOP       = "com.colortuner.STOP"
        const val ACTION_UPDATE     = "com.colortuner.UPDATE"
        const val BROADCAST_STOPPED = "com.colortuner.SERVICE_STOPPED"

        fun start(context: Context) {
            context.startForegroundService(Intent(context, ColorService::class.java))
        }
        fun stop(context: Context) {
            context.startService(
                Intent(context, ColorService::class.java).apply { action = ACTION_STOP })
        }
        fun update(context: Context) {
            context.startService(
                Intent(context, ColorService::class.java).apply { action = ACTION_UPDATE })
        }

        // ── Color matrix math ─────────────────────────────────────────────
        // Builds a 3×4 float matrix (row-major) combining temperature,
        // saturation, gamma and per-channel RGB scale.
        // SurfaceFlinger 1015 format: i32 1 f m0 f m1 ... f m11
        // Layout:  R'= m0*R + m1*G + m2*B + m3
        //          G'= m4*R + m5*G + m6*B + m7
        //          B'= m8*R + m9*G + m10*B + m11

        fun buildMatrix(
            kelvin: Int,
            saturation: Float,  // 0..1
            gamma: Float,       // 1.0 = neutral
            rScale: Float,      // 0..1
            gScale: Float,
            bScale: Float
        ): FloatArray {
            // 1. Kelvin → RGB multipliers
            //    Warm side (≤6500K): Tanner Helland normalized so 6500K = (1,1,1)
            //    Cool side (>6500K): linearly reduce R from 1→0 as K goes 6500→10000
            //    This gives symmetric visual impact on both sides.
            val (krn, kgn, kbn) = kelvinToRgbNormalized(kelvin)

            // 2. Gamma → simple brightness scale: gs = 2^(1-γ)
            //    γ=1.0 → gs=1.0 (neutral), γ>1 → gs<1 (darker), γ<1 → gs>1 (brighter)
            //    Exact midtone: g(0.5) = 2^(1-γ) * 0.5 = 0.5^γ ✓
            //    No offset — keeps black at 0 for darkening, clips white for brightening
            val gs = 2f.pow(1f - gamma)

            // 3. Combined per-channel scale
            val dr = (krn * rScale * gs).coerceIn(0f, 4f)
            val dg = (kgn * gScale * gs).coerceIn(0f, 4f)
            val db = (kbn * bScale * gs).coerceIn(0f, 4f)

            // 4. Saturation — equal (1/3) weights per channel
            val s = saturation
            val w = 1f / 3f
            val srr = w*(1-s)+s;  val srg = w*(1-s);    val srb = w*(1-s)
            val sgr = w*(1-s);    val sgg = w*(1-s)+s;  val sgb = w*(1-s)
            val sbr = w*(1-s);    val sbg = w*(1-s);    val sbb = w*(1-s)+s

            // 5. Compose: scale × sat (no offset)
            return floatArrayOf(
                dr*srr, dr*srg, dr*srb, 0f,
                dg*sgr, dg*sgg, dg*sgb, 0f,
                db*sbr, db*sbg, db*sbb, 0f
            )
        }

        private fun kelvinToRgbNormalized(kelvin: Int): Triple<Float, Float, Float> {
            return if (kelvin <= 6500) {
                // Warm side: Tanner Helland formula, normalized at 6500K = (1,1,1)
                val (kr, kg, kb) = kelvinToRgb(kelvin)
                val (nr, ng, nb) = kelvinToRgb(6500)
                Triple(
                    (kr / nr).coerceIn(0f, 1f),
                    (kg / ng).coerceIn(0f, 1f),
                    (kb / nb).coerceIn(0f, 1f)
                )
            } else {
                // Cool side: linearly reduce R from 1.0 → 0.0 as kelvin goes 6500 → 10000
                // G and B stay at 1.0 — this gives the same visual oomph as the warm side
                val t = (kelvin - 6500f) / (10000f - 6500f)
                Triple((1f - t).coerceIn(0f, 1f), 1f, 1f)
            }
        }

        private fun kelvinToRgb(kelvin: Int): Triple<Float, Float, Float> {
            val t = kelvin.toDouble() / 100.0
            val r: Float = if (t <= 66) 1f
                else (329.698727446 * (t - 60).pow(-0.1332047592))
                    .coerceIn(0.0, 255.0).toFloat() / 255f
            val g: Float = if (t <= 66)
                (99.4708025861 * ln(t) - 161.1195681661).coerceIn(0.0, 255.0).toFloat() / 255f
            else
                (288.1221695283 * (t - 60).pow(-0.0755148492)).coerceIn(0.0, 255.0).toFloat() / 255f
            val b: Float = when {
                t >= 66 -> 1f
                t <= 19 -> 0f
                else    -> (138.5177312231 * ln(t - 10) - 305.0447927307)
                    .coerceIn(0.0, 255.0).toFloat() / 255f
            }
            return Triple(r, g, b)
        }

        fun matrixToSFCommand(m: FloatArray): String {
            // SurfaceFlinger 1015 with i32 1 prefix expects 12 floats.
            // Verified format (yellow test): 3 groups of 4, column-major 3×4.
            // Transpose the 3×3 colour part; pass offsets m[3],m[7],m[11]
            // as the 4th value in each group (offset column).
            val t = floatArrayOf(
                m[0], m[4], m[8],  m[3],   // col 0 + R offset
                m[1], m[5], m[9],  m[7],   // col 1 + G offset
                m[2], m[6], m[10], m[11]   // col 2 + B offset
            )
            val floats = t.joinToString(" ") { "f ${"%.6f".format(it)}" }
            return "service call SurfaceFlinger 1015 i32 1 $floats"
        }

        val IDENTITY_CMD = matrixToSFCommand(floatArrayOf(
            1f, 0f, 0f, 0f,
            0f, 1f, 0f, 0f,
            0f, 0f, 1f, 0f
        ))
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        registerReceiver(screenOnReceiver, IntentFilter(Intent.ACTION_SCREEN_ON))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                doStop()
                return START_NOT_STICKY
            }
            ACTION_UPDATE -> {
                applyCurrentMatrix()
                updateNotification()
                return START_STICKY
            }
        }
        startForeground(NOTIF_ID, buildNotification())
        applyCurrentMatrix()
        return START_STICKY
    }

    override fun onDestroy() {
        try { unregisterReceiver(screenOnReceiver) } catch (e: Exception) { }
        getSharedPreferences("colortuner", Context.MODE_PRIVATE)
            .edit().putBoolean("serviceEnabled", false).apply()
        shell(IDENTITY_CMD)
        sendBroadcast(Intent(BROADCAST_STOPPED))
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun doStop() {
        getSharedPreferences("colortuner", Context.MODE_PRIVATE)
            .edit().putBoolean("serviceEnabled", false).apply()
        shell(IDENTITY_CMD)
        sendBroadcast(Intent(BROADCAST_STOPPED))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun applyCurrentMatrix() {
        val p = getSharedPreferences("colortuner", Context.MODE_PRIVATE)
        val kelvin = p.getInt("kelvin", 6500)
        val sat    = p.getInt("seekSat",   100) / 100f
        val gamma  = p.getFloat("gamma",   1f)
        val red    = p.getInt("seekRed",   100) / 100f
        val green  = p.getInt("seekGreen", 100) / 100f
        val blue   = p.getInt("seekBlue",  100) / 100f

        val m   = buildMatrix(kelvin, sat, gamma, red, green, blue)
        val cmd = matrixToSFCommand(m)
        Log.d("ColorTuner", "Matrix apply: ${kelvin}K sat=$sat gamma=$gamma")
        val result = shell(cmd)
        Log.d("ColorTuner", "SF 1015 exit=$result")
    }

    private fun shell(cmd: String): Int {
        // Try Shizuku first (works without root)
        if (shizukuReady()) {
            try {
                val process = Shizuku.newProcess(arrayOf("sh", "-c", cmd), null, null)
                val exit = process.waitFor()
                Log.d("ColorTuner", "Shizuku exit=$exit")
                if (exit == 0) return 0
            } catch (e: Exception) {
                Log.w("ColorTuner", "Shizuku.newProcess failed: ${e.message}")
            }
        }
        // Fallback: su (rooted devices)
        return try {
            val exit = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)).waitFor()
            Log.d("ColorTuner", "su exit=$exit")
            exit
        } catch (e: Exception) {
            Log.e("ColorTuner", "su failed: ${e.message}")
            -1
        }
    }

    private fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() &&
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Exception) { false }

    // ── Notification ──────────────────────────────────────────────────────

    private fun buildNotification(): Notification {
        val p      = getSharedPreferences("colortuner", Context.MODE_PRIVATE)
        val kelvin = p.getInt("kelvin", 6500)
        val sat    = p.getInt("seekSat", 100)
        val gamma  = p.getFloat("gamma", 1f)
        val red    = p.getInt("seekRed",   100)
        val green  = p.getInt("seekGreen", 100)
        val blue   = p.getInt("seekBlue",  100)

        val rgbPart = if (red == 100 && green == 100 && blue == 100) ""
                      else "  R$red G$green B$blue"
        val text = "${kelvin}K  •  sat $sat  •  γ${"%.2f".format(gamma)}$rgbPart"

        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, ColorService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Color Tuner active")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", stopIntent).build())
            .build()
    }

    private fun updateNotification() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIF_ID, buildNotification())
    }

    private fun createNotificationChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Color Tuner",
            NotificationManager.IMPORTANCE_LOW).apply {
            description = "Display color matrix active"
            setShowBadge(false)
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(ch)
    }
}
