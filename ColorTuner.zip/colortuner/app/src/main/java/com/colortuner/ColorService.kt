package com.colortuner

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.IBinder
import android.util.Log
import kotlin.math.*

class ColorService : Service() {

    private val CHANNEL_ID = "colortuner_service"
    private val NOTIF_ID   = 1

    // Reapply when screen turns on (SurfaceFlinger resets on wake sometimes)
    private val screenOnReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_SCREEN_ON) {
                Log.d("ColorTuner", "Screen on — reapplying matrix")
                applyCurrentMatrix()
            }
        }
    }

    companion object {
        const val ACTION_STOP       = "com.colortuner.STOP"
        const val ACTION_UPDATE     = "com.colortuner.UPDATE"
        const val BROADCAST_STOPPED = "com.colortuner.SERVICE_STOPPED"

        fun start(context: Context) {
            context.startForegroundService(Intent(context, ColorService::class.java))
        }
        fun stop(context: Context) {
            context.startService(
                Intent(context, ColorService::class.java).apply { action = ACTION_STOP })
        }
        fun update(context: Context) {
            context.startService(
                Intent(context, ColorService::class.java).apply { action = ACTION_UPDATE })
        }

        // ── Color matrix math ─────────────────────────────────────────────
        // Builds a 3×4 float matrix (row-major) combining temperature,
        // saturation, gamma and per-channel RGB scale.
        // SurfaceFlinger 1015 format: i32 1 f m0 f m1 ... f m11
        // Layout:  R'= m0*R + m1*G + m2*B + m3
        //          G'= m4*R + m5*G + m6*B + m7
        //          B'= m8*R + m9*G + m10*B + m11

        fun buildMatrix(
            kelvin: Int,
            saturation: Float,  // 0..1
            gamma: Float,       // e.g. 1.0 neutral
            rScale: Float,      // 0..1
            gScale: Float,
            bScale: Float
        ): FloatArray {
            // 1. Kelvin → per-channel multiplier (Tanner Helland approximation)
            val (kr, kg, kb) = kelvinToRgb(kelvin)

            // 2. Gamma → midtone brightness scale per channel
            //    At gamma=1.0 → scale=1.0, gamma>1 → darker, gamma<1 → brighter
            //    Using 2^(1-gamma) which is exact at 0, 0.5, and 1.0
            val gs = 2f.pow(1f - gamma)

            // 3. Combined diagonal scale (kelvin * rgb * gamma)
            val dr = (kr * rScale * gs).coerceIn(0f, 4f)
            val dg = (kg * gScale * gs).coerceIn(0f, 4f)
            val db = (kb * bScale * gs).coerceIn(0f, 4f)

            // 4. Saturation matrix (Rec.709 luma weights, luminance-preserving)
            val s  = saturation
            val lr = 0.2126f; val lg = 0.7152f; val lb = 0.0722f
            // Sat matrix applied first (row-major 3×3, no offset):
            // [ lr(1-s)+s   lg(1-s)     lb(1-s)   ]
            // [ lr(1-s)     lg(1-s)+s   lb(1-s)   ]
            // [ lr(1-s)     lg(1-s)     lb(1-s)+s ]
            val srr = lr*(1-s)+s;  val srg = lg*(1-s);    val srb = lb*(1-s)
            val sgr = lr*(1-s);    val sgg = lg*(1-s)+s;  val sgb = lb*(1-s)
            val sbr = lr*(1-s);    val sbg = lg*(1-s);    val sbb = lb*(1-s)+s

            // 5. Compose: result = diag(dr,dg,db) * sat
            //    (apply saturation first, then scale each channel)
            return floatArrayOf(
                dr*srr, dr*srg, dr*srb, 0f,   // R row
                dg*sgr, dg*sgg, dg*sgb, 0f,   // G row
                db*sbr, db*sbg, db*sbb, 0f    // B row
            )
        }

        private fun kelvinToRgb(kelvin: Int): Triple<Float, Float, Float> {
            val t = kelvin.toDouble() / 100.0
            val r: Float = if (t <= 66) 1f
                else (329.698727446 * (t - 60).pow(-0.1332047592))
                    .coerceIn(0.0, 255.0).toFloat() / 255f
            val g: Float = if (t <= 66)
                (99.4708025861 * ln(t) - 161.1195681661).coerceIn(0.0, 255.0).toFloat() / 255f
            else
                (288.1221695283 * (t - 60).pow(-0.0755148492)).coerceIn(0.0, 255.0).toFloat() / 255f
            val b: Float = when {
                t >= 66 -> 1f
                t <= 19 -> 0f
                else    -> (138.5177312231 * ln(t - 10) - 305.0447927307)
                    .coerceIn(0.0, 255.0).toFloat() / 255f
            }
            return Triple(r, g, b)
        }

        fun matrixToSFCommand(m: FloatArray): String {
            val floats = m.joinToString(" ") { "f ${"%.6f".format(it)}" }
            return "service call SurfaceFlinger 1015 i32 1 $floats"
        }

        val IDENTITY_CMD = matrixToSFCommand(floatArrayOf(
            1f, 0f, 0f, 0f,
            0f, 1f, 0f, 0f,
            0f, 0f, 1f, 0f
        ))
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        registerReceiver(screenOnReceiver, IntentFilter(Intent.ACTION_SCREEN_ON))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                doStop()
                return START_NOT_STICKY
            }
            ACTION_UPDATE -> {
                applyCurrentMatrix()
                updateNotification()
                return START_STICKY
            }
        }
        startForeground(NOTIF_ID, buildNotification())
        applyCurrentMatrix()
        return START_STICKY
    }

    override fun onDestroy() {
        try { unregisterReceiver(screenOnReceiver) } catch (e: Exception) { }
        getSharedPreferences("colortuner", Context.MODE_PRIVATE)
            .edit().putBoolean("serviceEnabled", false).apply()
        shell(IDENTITY_CMD)
        sendBroadcast(Intent(BROADCAST_STOPPED))
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun doStop() {
        getSharedPreferences("colortuner", Context.MODE_PRIVATE)
            .edit().putBoolean("serviceEnabled", false).apply()
        shell(IDENTITY_CMD)
        sendBroadcast(Intent(BROADCAST_STOPPED))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun applyCurrentMatrix() {
        val p = getSharedPreferences("colortuner", Context.MODE_PRIVATE)
        val kelvin = p.getInt("kelvin", 6500)
        val sat    = p.getInt("seekSat",   100) / 100f
        val gamma  = p.getFloat("gamma",   1f)
        val red    = p.getInt("seekRed",   100) / 100f
        val green  = p.getInt("seekGreen", 100) / 100f
        val blue   = p.getInt("seekBlue",  100) / 100f

        val m   = buildMatrix(kelvin, sat, gamma, red, green, blue)
        val cmd = matrixToSFCommand(m)
        Log.d("ColorTuner", "Matrix apply: ${kelvin}K sat=$sat gamma=$gamma")
        val result = shell(cmd)
        Log.d("ColorTuner", "SF 1015 exit=$result")
    }

    private fun shell(cmd: String): Int {
        return try {
            Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)).waitFor()
        } catch (e: Exception) {
            Log.e("ColorTuner", "shell failed: ${e.message}")
            -1
        }
    }

    // ── Notification ──────────────────────────────────────────────────────

    private fun buildNotification(): Notification {
        val p      = getSharedPreferences("colortuner", Context.MODE_PRIVATE)
        val kelvin = p.getInt("kelvin", 6500)
        val sat    = p.getInt("seekSat", 100)
        val gamma  = p.getFloat("gamma", 1f)

        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, ColorService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Color Tuner active")
            .setContentText("${kelvin}K  •  sat $sat  •  γ${"%.2f".format(gamma)}")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", stopIntent).build())
            .build()
    }

    private fun updateNotification() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIF_ID, buildNotification())
    }

    private fun createNotificationChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Color Tuner",
            NotificationManager.IMPORTANCE_LOW).apply {
            description = "Display color matrix active"
            setShowBadge(false)
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(ch)
    }
}
