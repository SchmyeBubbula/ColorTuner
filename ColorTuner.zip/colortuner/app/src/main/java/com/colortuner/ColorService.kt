package com.colortuner

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log

class ColorService : Service() {

    private val CHANNEL_ID = "colortuner_service"
    private val NOTIF_ID   = 1
    private val INTERVAL   = 500L // ms — tight enough to beat Android's reassertion

    private val handler = Handler(Looper.getMainLooper())
    private val watchdog = object : Runnable {
        override fun run() {
            applyCurrentSettings()
            handler.postDelayed(this, INTERVAL)
        }
    }

    companion object {
        const val ACTION_STOP        = "com.colortuner.STOP"
        const val ACTION_UPDATE      = "com.colortuner.UPDATE"
        const val BROADCAST_STOPPED  = "com.colortuner.SERVICE_STOPPED"

        fun start(context: Context) {
            context.startForegroundService(Intent(context, ColorService::class.java))
        }
        fun stop(context: Context) {
            context.startService(
                Intent(context, ColorService::class.java).apply { action = ACTION_STOP })
        }
        fun update(context: Context) {
            context.startService(
                Intent(context, ColorService::class.java).apply { action = ACTION_UPDATE })
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                doStop()
                return START_NOT_STICKY
            }
            ACTION_UPDATE -> {
                handler.removeCallbacks(watchdog)
                applyCurrentSettings()
                handler.postDelayed(watchdog, INTERVAL)
                updateNotification()
                return START_STICKY
            }
        }
        startForeground(NOTIF_ID, buildNotification())
        applyCurrentSettings()
        handler.postDelayed(watchdog, INTERVAL)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(watchdog)
        // Write to prefs so MainActivity sees the stop even if broadcast is missed
        getSharedPreferences("colortuner", Context.MODE_PRIVATE)
            .edit().putBoolean("serviceEnabled", false).apply()
        resetDisplay()
        sendBroadcast(Intent(BROADCAST_STOPPED))
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun doStop() {
        handler.removeCallbacks(watchdog)
        getSharedPreferences("colortuner", Context.MODE_PRIVATE)
            .edit().putBoolean("serviceEnabled", false).apply()
        resetDisplay()
        sendBroadcast(Intent(BROADCAST_STOPPED))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ── Apply / Reset ─────────────────────────────────────────────────────

    private fun applyCurrentSettings() {
        val prefs  = getSharedPreferences("colortuner", Context.MODE_PRIVATE)
        val kelvin = prefs.getInt("kelvin", 6500)
        val sat    = prefs.getInt("seekSat", 100)
        Log.d("ColorTuner", "Watchdog apply: ${kelvin}K sat=$sat")
        // Single su -c call — one root grant, all commands in one shot
        shell(
            "cmd color_display set-layer-saturation 100 android android" +
            " && cmd color_display set-saturation $sat" +
            " && cmd display dwb-set-cct $kelvin"
        )
    }

    private fun resetDisplay() {
        shell(
            "cmd color_display set-saturation 100" +
            " && cmd display dwb-set-cct -1" +
            " && settings put secure night_display_activated 0"
        )
    }

    private fun shell(cmd: String): Int {
        return try {
            Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)).waitFor()
        } catch (e: Exception) {
            Log.e("ColorTuner", "shell failed: ${e.message}")
            -1
        }
    }

    // ── Notification ──────────────────────────────────────────────────────

    private fun buildNotification(): Notification {
        val prefs  = getSharedPreferences("colortuner", Context.MODE_PRIVATE)
        val kelvin = prefs.getInt("kelvin", 6500)
        val sat    = prefs.getInt("seekSat", 100)

        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, ColorService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Color Tuner active")
            .setContentText("${kelvin}K  •  sat $sat")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", stopIntent).build())
            .build()
    }

    private fun updateNotification() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIF_ID, buildNotification())
    }

    private fun createNotificationChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Color Tuner",
            NotificationManager.IMPORTANCE_LOW).apply {
            description = "Keeps display color settings active"
            setShowBadge(false)
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(ch)
    }
}
