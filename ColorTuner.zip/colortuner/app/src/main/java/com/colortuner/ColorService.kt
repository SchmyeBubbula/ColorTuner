package com.colortuner

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log

class ColorService : Service() {

    private val CHANNEL_ID = "colortuner_service"
    private val NOTIF_ID   = 1

    companion object {
        const val ACTION_STOP   = "com.colortuner.STOP"
        const val ACTION_UPDATE = "com.colortuner.UPDATE"
        // Broadcast sent when service stops, so MainActivity can update its button
        const val BROADCAST_STOPPED = "com.colortuner.SERVICE_STOPPED"

        fun start(context: Context) {
            context.startForegroundService(Intent(context, ColorService::class.java))
        }
        fun stop(context: Context) {
            context.startService(
                Intent(context, ColorService::class.java).apply { action = ACTION_STOP }
            )
        }
        fun update(context: Context) {
            context.startService(
                Intent(context, ColorService::class.java).apply { action = ACTION_UPDATE }
            )
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                applyDefaults()
                sendBroadcast(Intent(BROADCAST_STOPPED))
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_UPDATE -> {
                applyCurrentSettings()
                updateNotification()
                return START_STICKY
            }
        }
        // Initial start
        startForeground(NOTIF_ID, buildNotification())
        applyCurrentSettings()
        return START_STICKY
    }

    override fun onDestroy() {
        // Also broadcast if killed by system (not via ACTION_STOP)
        sendBroadcast(Intent(BROADCAST_STOPPED))
        applyDefaults()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ── Apply settings via ColorDisplayManager reflection ─────────────────

    private fun applyCurrentSettings() {
        val prefs  = getSharedPreferences("colortuner", Context.MODE_PRIVATE)
        val kelvin = prefs.getInt("kelvin", 6500)
        val sat    = prefs.getInt("seekSat", 100)
        val gamma  = prefs.getFloat("gamma", 1f)
        val red    = prefs.getInt("seekRed",   100)
        val green  = prefs.getInt("seekGreen", 100)
        val blue   = prefs.getInt("seekBlue",  100)

        Log.d("ColorTuner", "Applying: ${kelvin}K sat=$sat gamma=$gamma R=$red G=$green B=$blue")

        setSaturation(sat)
        setColorTemperature(kelvin)
    }

    private fun applyDefaults() {
        setSaturation(100)
        setColorTemperature(6500)
    }

    // Call ColorDisplayManager.setSaturationLevel(int level) via reflection.
    // Level 0 = grayscale, 100 = full saturation.
    // Calling this registers our service as the owner — Android won't reset it
    // as long as this process is alive.
    private fun setSaturation(level: Int) {
        try {
            val cdm = getColorDisplayManager() ?: return
            val method = cdm.javaClass.getDeclaredMethod("setSaturationLevel", Int::class.java)
            method.isAccessible = true
            method.invoke(cdm, level)
            Log.d("ColorTuner", "setSaturationLevel($level) OK")
        } catch (e: Exception) {
            Log.e("ColorTuner", "setSaturationLevel failed: ${e.message}")
        }
    }

    // Call ColorDisplayManager.setColorTemperature(int cct) via reflection.
    // This drives the display white balance hardware pipeline directly.
    private fun setColorTemperature(kelvin: Int) {
        try {
            val cdm = getColorDisplayManager() ?: return
            // Try setColorTemperature first (hardware white balance)
            try {
                val method = cdm.javaClass.getDeclaredMethod("setColorTemperature", Int::class.java)
                method.isAccessible = true
                method.invoke(cdm, kelvin)
                Log.d("ColorTuner", "setColorTemperature($kelvin) OK")
                return
            } catch (e: NoSuchMethodException) {
                Log.w("ColorTuner", "setColorTemperature not found, trying night display")
            }
            // Fallback: set night display temperature
            val setTemp = cdm.javaClass.getDeclaredMethod(
                "setNightDisplayColorTemperature", Int::class.java)
            setTemp.isAccessible = true
            setTemp.invoke(cdm, kelvin)
            val setActivated = cdm.javaClass.getDeclaredMethod(
                "setNightDisplayActivated", Boolean::class.java)
            setActivated.isAccessible = true
            setActivated.invoke(cdm, kelvin < 6500)
            Log.d("ColorTuner", "setNightDisplayColorTemperature($kelvin) OK")
        } catch (e: Exception) {
            Log.e("ColorTuner", "setColorTemperature failed: ${e.message}")
        }
    }

    private fun getColorDisplayManager(): Any? {
        return try {
            getSystemService("color_display")
                ?: Class.forName("android.hardware.display.ColorDisplayManager")
                    .getDeclaredMethod("getInstance", Context::class.java)
                    .also { it.isAccessible = true }
                    .invoke(null, this)
        } catch (e: Exception) {
            Log.e("ColorTuner", "getColorDisplayManager failed: ${e.message}")
            null
        }
    }

    // ── Notification ──────────────────────────────────────────────────────

    private fun buildNotification(): Notification {
        val prefs  = getSharedPreferences("colortuner", Context.MODE_PRIVATE)
        val kelvin = prefs.getInt("kelvin", 6500)
        val sat    = prefs.getInt("seekSat", 100)
        val gamma  = prefs.getFloat("gamma", 1f)

        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, ColorService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Color Tuner active")
            .setContentText("${kelvin}K  •  sat $sat  •  \u03b3${"%.2f".format(gamma)}")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", stopIntent).build())
            .build()
    }

    private fun updateNotification() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification())
    }

    private fun createNotificationChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Color Tuner",
            NotificationManager.IMPORTANCE_LOW).apply {
            description = "Keeps display color settings active"
            setShowBadge(false)
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(ch)
    }
}
