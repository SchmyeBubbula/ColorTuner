package com.colortuner

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log

class WatchdogService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val CHANNEL_ID = "colortuner_watchdog"
    private val NOTIF_ID = 1
    private val INTERVAL_MS = 30_000L // reapply every 30 seconds

    private val watchdogRunnable = object : Runnable {
        override fun run() {
            applyCurrentSettings()
            handler.postDelayed(this, INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }

        val prefs = getSharedPreferences("colortuner", Context.MODE_PRIVATE)
        val kelvin = progressToKelvin(prefs.getInt("seekTemp", 100))
        val sat    = prefs.getInt("seekSat", 100)
        val mode   = prefs.getString("tempMode", "night") ?: "night"

        startForeground(NOTIF_ID, buildNotification(kelvin, sat, mode))

        // Apply immediately, then start watchdog loop
        applyCurrentSettings()
        handler.removeCallbacks(watchdogRunnable)
        handler.postDelayed(watchdogRunnable, INTERVAL_MS)

        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(watchdogRunnable)
        // Reset display when service is explicitly stopped
        runCommand("cmd color_display set-saturation 100")
        runCommand("settings put secure night_display_activated 0")
        runCommand("cmd display dwb-set-cct -1")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ── Apply settings ────────────────────────────────────────────────────

    private fun applyCurrentSettings() {
        val prefs  = getSharedPreferences("colortuner", Context.MODE_PRIVATE)
        val kelvin = progressToKelvin(prefs.getInt("seekTemp", 100))
        val sat    = prefs.getInt("seekSat", 100)
        val mode   = prefs.getString("tempMode", "night") ?: "night"

        Log.d("ColorTuner", "Watchdog applying: ${kelvin}K sat=$sat mode=$mode")

        when (mode) {
            "night" -> {
                if (kelvin < 6500) {
                    runCommand("settings put secure night_display_color_temperature $kelvin")
                    runCommand("settings put secure night_display_activated 1")
                } else {
                    runCommand("settings put secure night_display_activated 0")
                    runCommand("settings delete secure night_display_color_temperature")
                }
                runCommand("cmd display dwb-set-cct -1")
            }
            "dwb" -> {
                runCommand("settings put secure night_display_activated 0")
                runCommand("cmd display dwb-set-cct $kelvin")
            }
        }
        runCommand("cmd color_display set-saturation $sat")

        // Update notification with current values
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(kelvin, sat, mode))
    }

    // ── Notification ──────────────────────────────────────────────────────

    private fun buildNotification(kelvin: Int, sat: Int, mode: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, WatchdogService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )
        val modeLabel = if (mode == "night") "Night" else "WB"
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Color Tuner active")
            .setContentText("${kelvin}K  •  sat $sat  •  $modeLabel")
            .setSmallIcon(android.R.drawable.ic_menu_camera) // replaced by our icon at runtime
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    null, "Stop",
                    stopIntent
                ).build()
            )
            .build()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Color Tuner Watchdog",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Keeps display color correction active"
            setShowBadge(false)
        }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(channel)
    }

    // ── Shell ─────────────────────────────────────────────────────────────

    private fun runCommand(cmd: String): Boolean {
        return try {
            Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)).waitFor() == 0
        } catch (e: Exception) {
            Log.e("ColorTuner", "Watchdog cmd failed: $cmd", e)
            false
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private val TEMP_MIN = 3000; private val TEMP_MAX = 8000
    private fun progressToKelvin(p: Int) = TEMP_MIN + p * (TEMP_MAX - TEMP_MIN) / 100

    companion object {
        const val ACTION_STOP = "com.colortuner.STOP_WATCHDOG"

        fun start(context: Context) {
            context.startForegroundService(
                Intent(context, WatchdogService::class.java)
            )
        }

        fun stop(context: Context) {
            context.startService(
                Intent(context, WatchdogService::class.java).apply { action = ACTION_STOP }
            )
        }
    }
}
