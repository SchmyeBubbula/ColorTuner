package com.colortuner

import android.app.Application
import org.chickenhook.restrictionbypass.Unseal

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // Bypass Android's hidden API restrictions so we can call
        // ColorDisplayManager.setSaturationLevel() and setColorTemperature()
        // via reflection. Must be done before any reflection calls.
        try {
            Unseal.unseal()
        } catch (e: Exception) {
            android.util.Log.e("ColorTuner", "RestrictionBypass failed: ${e.message}")
        }
    }
}
