package com.colortuner

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.snackbar.Snackbar
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.*

class MainActivity : AppCompatActivity() {

    // ── Views ──────────────────────────────────────────────────────────────
    private lateinit var tvStatus: TextView
    private lateinit var seekTemp: SeekBar;  private lateinit var etTempValue: EditText
    private lateinit var seekSat: SeekBar;   private lateinit var etSatValue: EditText
    private lateinit var seekGamma: SeekBar; private lateinit var etGammaValue: EditText
    private lateinit var seekRed: SeekBar;   private lateinit var etRedValue: EditText
    private lateinit var seekGreen: SeekBar; private lateinit var etGreenValue: EditText
    private lateinit var seekBlue: SeekBar;  private lateinit var etBlueValue: EditText
    private lateinit var layoutProfiles: LinearLayout
    private lateinit var etProfileName: EditText
    private lateinit var btnSave: MaterialButton
    private lateinit var btnReset: MaterialButton
    private lateinit var btnService: MaterialButton
    private lateinit var scrollRoot: ScrollView

    private lateinit var prefs: SharedPreferences
    private var updatingFromSlider = false
    private var updatingFromEdit   = false

    // Debounce live updates so we don't hammer the service on every pixel of slider drag
    private val updateHandler = Handler(Looper.getMainLooper())
    private val updateRunnable = Runnable {
        saveSliders()
        if (prefs.getBoolean("serviceEnabled", false)) {
            ColorService.update(this)
        }
    }

    private val TEMP_MIN = 1000; private val TEMP_MAX = 10000
    private val GAMMA_MIN = 0.50f; private val GAMMA_MAX = 3.50f

    // ── Broadcast receiver — listens for service stopped from notification ─
    private val serviceStoppedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == ColorService.BROADCAST_STOPPED) {
                prefs.edit().putBoolean("serviceEnabled", false).apply()
                updateServiceButton()
            }
        }
    }

    // ── Notification permission launcher ───────────────────────────────────
    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startService() else snack("Notification permission needed for service")
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("colortuner", Context.MODE_PRIVATE)

        bindViews()
        setupSliders()
        setupDismissKeyboard()

        btnReset.setOnClickListener   { resetAll() }
        btnSave.setOnClickListener    { saveProfile() }
        btnService.setOnClickListener { toggleService() }

        restoreSliders()
        updateServiceButton()
        updateStatus()
        renderProfiles()
    }

    override fun onResume() {
        super.onResume()
        // Register broadcast receiver to catch notification Stop tap
        val filter = IntentFilter(ColorService.BROADCAST_STOPPED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(serviceStoppedReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(serviceStoppedReceiver, filter)
        }
        updateServiceButton()
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(serviceStoppedReceiver)
    }

    // ── View binding ──────────────────────────────────────────────────────

    private fun bindViews() {
        scrollRoot     = findViewById(R.id.scrollRoot)
        tvStatus       = findViewById(R.id.tvStatus)
        seekTemp       = findViewById(R.id.seekTemp);   etTempValue  = findViewById(R.id.etTempValue)
        seekSat        = findViewById(R.id.seekSat);    etSatValue   = findViewById(R.id.etSatValue)
        seekGamma      = findViewById(R.id.seekGamma);  etGammaValue = findViewById(R.id.etGammaValue)
        seekRed        = findViewById(R.id.seekRed);    etRedValue   = findViewById(R.id.etRedValue)
        seekGreen      = findViewById(R.id.seekGreen);  etGreenValue = findViewById(R.id.etGreenValue)
        seekBlue       = findViewById(R.id.seekBlue);   etBlueValue  = findViewById(R.id.etBlueValue)
        layoutProfiles = findViewById(R.id.layoutProfiles)
        etProfileName  = findViewById(R.id.etProfileName)
        btnSave        = findViewById(R.id.btnSave)
        btnReset       = findViewById(R.id.btnReset)
        btnService     = findViewById(R.id.btnService)
    }

    // ── Slider setup ──────────────────────────────────────────────────────

    private fun setupSliders() {
        linkSlider(seekTemp, etTempValue,
            toDisplay = { p -> "${progressToKelvin(p)}" },
            fromText  = { t -> kelvinToProgress(t.trim().toIntOrNull() ?: 6500) })
        linkSlider(seekSat, etSatValue,
            toDisplay = { p -> "$p" },
            fromText  = { t -> t.trim().toIntOrNull()?.coerceIn(0, 100) ?: 100 })
        linkSlider(seekGamma, etGammaValue,
            toDisplay = { p -> "%.2f".format(progressToGamma(p)) },
            fromText  = { t -> gammaToProgress(t.trim().toFloatOrNull() ?: 1f) })
        linkSlider(seekRed, etRedValue,
            toDisplay = { p -> "$p" },
            fromText  = { t -> t.trim().toIntOrNull()?.coerceIn(0, 100) ?: 100 })
        linkSlider(seekGreen, etGreenValue,
            toDisplay = { p -> "$p" },
            fromText  = { t -> t.trim().toIntOrNull()?.coerceIn(0, 100) ?: 100 })
        linkSlider(seekBlue, etBlueValue,
            toDisplay = { p -> "$p" },
            fromText  = { t -> t.trim().toIntOrNull()?.coerceIn(0, 100) ?: 100 })
    }

    private fun linkSlider(seek: SeekBar, et: EditText,
                           toDisplay: (Int) -> String, fromText: (String) -> Int) {
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (updatingFromEdit) return
                updatingFromSlider = true
                et.setText(toDisplay(p))
                et.setSelection(et.text.length)
                updatingFromSlider = false
                if (fromUser) scheduleUpdate()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) { dismissKeyboard(sb) }
        })
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {
                if (updatingFromSlider) return
                updatingFromEdit = true
                seek.progress = fromText(s.toString())
                updatingFromEdit = false
                scheduleUpdate()
            }
            override fun beforeTextChanged(s: CharSequence, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence, a: Int, b: Int, c: Int) {}
        })
        et.setOnEditorActionListener { _, _, _ -> dismissKeyboard(et); true }
    }

    // Debounce: wait 300ms after last slider change before pushing to service
    private fun scheduleUpdate() {
        updateHandler.removeCallbacks(updateRunnable)
        updateHandler.postDelayed(updateRunnable, 300)
    }

    private fun setupDismissKeyboard() {
        scrollRoot.setOnTouchListener { _, _ ->
            dismissKeyboard(currentFocus ?: scrollRoot)
            false
        }
    }

    // ── Conversions ───────────────────────────────────────────────────────

    private fun progressToKelvin(p: Int) = TEMP_MIN + p * (TEMP_MAX - TEMP_MIN) / 100
    private fun kelvinToProgress(k: Int) =
        ((k - TEMP_MIN) * 100 / (TEMP_MAX - TEMP_MIN)).coerceIn(0, 100)

    private fun progressToGamma(p: Int): Float {
        val t = p / 100f
        return (GAMMA_MIN.pow(1f - t) * GAMMA_MAX.pow(t))
    }
    private fun gammaToProgress(g: Float): Int {
        val cg = g.coerceIn(GAMMA_MIN, GAMMA_MAX)
        return ((ln(cg / GAMMA_MIN) / ln(GAMMA_MAX / GAMMA_MIN)) * 100)
            .roundToInt().coerceIn(0, 100)
    }

    // ── Status ────────────────────────────────────────────────────────────

    private fun updateStatus() {
        tvStatus.text = "Color correction via ColorDisplayManager API"
        tvStatus.setTextColor(getColor(R.color.text_muted))
    }

    // ── Reset ─────────────────────────────────────────────────────────────

    private fun resetAll() {
        dismissKeyboard(currentFocus ?: btnReset)
        seekTemp.progress  = kelvinToProgress(6500)
        seekSat.progress   = 100
        seekGamma.progress = gammaToProgress(1f)
        seekRed.progress   = 100
        seekGreen.progress = 100
        seekBlue.progress  = 100
        saveSliders()
        if (prefs.getBoolean("serviceEnabled", false)) {
            ColorService.update(this)
        }
        snack("Reset to defaults ✓")
    }

    // ── Persist sliders ───────────────────────────────────────────────────

    private fun saveSliders() {
        prefs.edit()
            .putInt("kelvin",    progressToKelvin(seekTemp.progress))
            .putInt("seekSat",   seekSat.progress)
            .putFloat("gamma",   progressToGamma(seekGamma.progress))
            .putInt("seekRed",   seekRed.progress)
            .putInt("seekGreen", seekGreen.progress)
            .putInt("seekBlue",  seekBlue.progress)
            .apply()
    }

    private fun restoreSliders() {
        seekTemp.progress  = kelvinToProgress(prefs.getInt("kelvin", 6500))
        seekSat.progress   = prefs.getInt("seekSat", 100)
        seekGamma.progress = gammaToProgress(prefs.getFloat("gamma", 1f))
        seekRed.progress   = prefs.getInt("seekRed",   100)
        seekGreen.progress = prefs.getInt("seekGreen", 100)
        seekBlue.progress  = prefs.getInt("seekBlue",  100)
    }

    // ── Service toggle ────────────────────────────────────────────────────

    private fun toggleService() {
        val enabled = prefs.getBoolean("serviceEnabled", false)
        if (enabled) {
            ColorService.stop(this)
            prefs.edit().putBoolean("serviceEnabled", false).apply()
            updateServiceButton()
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
            startService()
        }
    }

    private fun startService() {
        saveSliders()
        ColorService.start(this)
        prefs.edit().putBoolean("serviceEnabled", true).apply()
        updateServiceButton()
    }

    private fun updateServiceButton() {
        val enabled = prefs.getBoolean("serviceEnabled", false)
        if (enabled) {
            btnService.text = "■  Stop Color Service"
            btnService.setTextColor(getColor(R.color.error))
        } else {
            btnService.text = "▶  Start Color Service"
            btnService.setTextColor(getColor(R.color.text_primary))
        }
    }

    // ── Profiles ──────────────────────────────────────────────────────────

    data class Profile(
        val name: String,
        val kelvin: Int, val sat: Int,
        val gamma: Float,
        val red: Int, val green: Int, val blue: Int
    )

    private val builtins = listOf(
        Profile("Neutral",    6500, 100, 1.00f, 100, 100, 100),
        Profile("Night Warm", 3200,  80, 1.20f, 100,  95,  85),
        Profile("Vivid",      6500, 100, 0.85f, 100, 100, 100),
        Profile("Reading",    3800,  75, 1.15f, 100,  95,  80),
        Profile("Cool",       8000, 100, 1.00f, 100, 100, 100),
    )

    private fun loadProfiles(): List<Profile> {
        return try {
            val arr = JSONArray(prefs.getString("profiles", "[]") ?: "[]")
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Profile(o.getString("name"), o.getInt("kelvin"), o.getInt("sat"),
                    o.optDouble("gamma", 1.0).toFloat(),
                    o.optInt("red", 100), o.optInt("green", 100), o.optInt("blue", 100))
            }
        } catch (e: Exception) { emptyList() }
    }

    private fun saveProfiles(profiles: List<Profile>) {
        val arr = JSONArray()
        profiles.forEach {
            arr.put(JSONObject().apply {
                put("name", it.name); put("kelvin", it.kelvin); put("sat", it.sat)
                put("gamma", it.gamma.toDouble())
                put("red", it.red); put("green", it.green); put("blue", it.blue)
            })
        }
        prefs.edit().putString("profiles", arr.toString()).apply()
    }

    private fun saveProfile() {
        val name = etProfileName.text.toString().trim()
        if (name.isEmpty()) { snack("Enter a profile name"); return }
        dismissKeyboard(etProfileName)
        val p = Profile(name, progressToKelvin(seekTemp.progress), seekSat.progress,
            progressToGamma(seekGamma.progress),
            seekRed.progress, seekGreen.progress, seekBlue.progress)
        val list = loadProfiles().toMutableList()
        list.removeAll { it.name == name }
        list.add(p)
        saveProfiles(list)
        etProfileName.text.clear()
        renderProfiles()
        snack("Saved \"$name\"")
    }

    private fun renderProfiles() {
        layoutProfiles.removeAllViews()
        (builtins + loadProfiles()).forEach { profile ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, 4, 0, 4)
            }
            val btn = MaterialButton(this, null,
                com.google.android.material.R.attr.borderlessButtonStyle).apply {
                text = "${profile.name}  •  ${profile.kelvin}K  •  sat ${profile.sat}  •  \u03b3${"%.2f".format(profile.gamma)}"
                textSize = 12f
                setTextColor(getColor(R.color.text_primary))
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { loadProfile(profile) }
            }
            row.addView(btn)
            if (builtins.none { it.name == profile.name }) {
                val del = MaterialButton(this, null,
                    com.google.android.material.R.attr.borderlessButtonStyle).apply {
                    text = "\u2715"; textSize = 12f
                    setTextColor(getColor(R.color.error))
                    setOnClickListener {
                        saveProfiles(loadProfiles().filter { it.name != profile.name })
                        renderProfiles()
                    }
                }
                row.addView(del)
            }
            layoutProfiles.addView(row)
        }
    }

    private fun loadProfile(p: Profile) {
        seekTemp.progress  = kelvinToProgress(p.kelvin)
        seekSat.progress   = p.sat
        seekGamma.progress = gammaToProgress(p.gamma)
        seekRed.progress   = p.red
        seekGreen.progress = p.green
        seekBlue.progress  = p.blue
        // scheduleUpdate is triggered automatically by the slider changes above
        snack("Loaded \"${p.name}\"")
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private fun dismissKeyboard(view: android.view.View) {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(view.windowToken, 0)
        view.clearFocus()
    }

    private fun snack(msg: String) =
        Snackbar.make(findViewById(android.R.id.content), msg, Snackbar.LENGTH_SHORT).show()
}
