package com.colortuner

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.snackbar.Snackbar
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    // ── Views ──────────────────────────────────────────────────────────────
    private lateinit var tvStatus: TextView
    private lateinit var seekTemp: SeekBar;  private lateinit var etTempValue: EditText
    private lateinit var seekSat: SeekBar;   private lateinit var etSatValue: EditText
    private lateinit var seekGamma: SeekBar; private lateinit var etGammaValue: EditText
    private lateinit var seekRed: SeekBar;   private lateinit var etRedValue: EditText
    private lateinit var seekGreen: SeekBar; private lateinit var etGreenValue: EditText
    private lateinit var seekBlue: SeekBar;  private lateinit var etBlueValue: EditText
    private lateinit var layoutProfiles: LinearLayout
    private lateinit var etProfileName: EditText
    private lateinit var btnSave: MaterialButton
    private lateinit var btnApply: MaterialButton
    private lateinit var btnReset: MaterialButton

    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    // Suppress feedback loops between slider and edittext
    private var updatingFromSlider = false
    private var updatingFromEdit = false

    private val TEMP_MIN = 3000; private val TEMP_MAX = 6500
    private val GAMMA_MIN = 0.75f; private val GAMMA_MAX = 3.5f
    private val SHIZUKU_CODE = 1001

    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { code, _ ->
        if (code == SHIZUKU_CODE) handler.post { updateStatus() }
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("colortuner", Context.MODE_PRIVATE)
        bindViews()
        linkSlider(seekTemp, etTempValue,
            toDisplay = { p -> "${progressToKelvin(p)} K" },
            fromText  = { t -> kelvinToProgress(t.replace(" K","").trim().toIntOrNull() ?: TEMP_MAX) })
        linkSlider(seekSat, etSatValue,
            toDisplay = { p -> "$p" },
            fromText  = { t -> t.trim().toIntOrNull()?.coerceIn(0,100) ?: 100 })
        linkSlider(seekGamma, etGammaValue,
            toDisplay = { p -> "%.2f".format(progressToGamma(p)) },
            fromText  = { t -> gammaToProgress(t.trim().toFloatOrNull() ?: 1f) })
        linkSlider(seekRed, etRedValue,
            toDisplay = { p -> "$p" },
            fromText  = { t -> t.trim().toIntOrNull()?.coerceIn(0,100) ?: 100 })
        linkSlider(seekGreen, etGreenValue,
            toDisplay = { p -> "$p" },
            fromText  = { t -> t.trim().toIntOrNull()?.coerceIn(0,100) ?: 100 })
        linkSlider(seekBlue, etBlueValue,
            toDisplay = { p -> "$p" },
            fromText  = { t -> t.trim().toIntOrNull()?.coerceIn(0,100) ?: 100 })
        btnApply.setOnClickListener { applySettings() }
        btnReset.setOnClickListener { resetSettings() }
        btnSave.setOnClickListener  { saveProfile() }
        Shizuku.addRequestPermissionResultListener(shizukuListener)
        restoreSliders()
        updateStatus()
        renderProfiles()
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(shizukuListener)
    }

    // ── View binding ──────────────────────────────────────────────────────

    private fun bindViews() {
        tvStatus      = findViewById(R.id.tvStatus)
        seekTemp      = findViewById(R.id.seekTemp);   etTempValue  = findViewById(R.id.etTempValue)
        seekSat       = findViewById(R.id.seekSat);    etSatValue   = findViewById(R.id.etSatValue)
        seekGamma     = findViewById(R.id.seekGamma);  etGammaValue = findViewById(R.id.etGammaValue)
        seekRed       = findViewById(R.id.seekRed);    etRedValue   = findViewById(R.id.etRedValue)
        seekGreen     = findViewById(R.id.seekGreen);  etGreenValue = findViewById(R.id.etGreenValue)
        seekBlue      = findViewById(R.id.seekBlue);   etBlueValue  = findViewById(R.id.etBlueValue)
        layoutProfiles = findViewById(R.id.layoutProfiles)
        etProfileName = findViewById(R.id.etProfileName)
        btnSave       = findViewById(R.id.btnSave)
        btnApply      = findViewById(R.id.btnApply)
        btnReset      = findViewById(R.id.btnReset)
    }

    // ── Slider <-> EditText two-way binding ───────────────────────────────

    private fun linkSlider(
        seek: SeekBar, et: EditText,
        toDisplay: (Int) -> String,
        fromText: (String) -> Int
    ) {
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (updatingFromEdit) return
                updatingFromSlider = true
                et.setText(toDisplay(p))
                et.setSelection(et.text.length)
                updatingFromSlider = false
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {
                if (updatingFromSlider) return
                updatingFromEdit = true
                seek.progress = fromText(s.toString())
                updatingFromEdit = false
            }
            override fun beforeTextChanged(s: CharSequence, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence, a: Int, b: Int, c: Int) {}
        })
    }

    // ── Conversions ───────────────────────────────────────────────────────

    private fun progressToKelvin(p: Int) = TEMP_MIN + p * (TEMP_MAX - TEMP_MIN) / 100
    private fun kelvinToProgress(k: Int) = ((k - TEMP_MIN) * 100 / (TEMP_MAX - TEMP_MIN)).coerceIn(0, 100)

    // Gamma: use log scale so middle of slider = 1.0 (neutral)
    // progress 0..100 → gamma 0.75..3.5 with ~50 = 1.0
    private fun progressToGamma(p: Int): Float {
        val t = p / 100f
        return (GAMMA_MIN.pow(1 - t) * GAMMA_MAX.pow(t))
    }
    private fun gammaToProgress(g: Float): Int {
        val clamped = g.coerceIn(GAMMA_MIN, GAMMA_MAX)
        return ((ln(clamped / GAMMA_MIN) / ln(GAMMA_MAX / GAMMA_MIN)) * 100).roundToInt().coerceIn(0, 100)
    }

    // ── Status ────────────────────────────────────────────────────────────

    private fun updateStatus() {
        val hasRoot = try {
            Runtime.getRuntime().exec(arrayOf("su", "-c", "true")).waitFor() == 0
        } catch (e: Exception) { false }

        try {
            when {
                hasRoot -> {
                    val shizuku = Shizuku.pingBinder() &&
                        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                    tvStatus.text = if (shizuku) "✓ Root + Shizuku ready" else "✓ Root ready (Shizuku optional)"
                    tvStatus.setTextColor(getColor(R.color.success))
                    tvStatus.setOnClickListener(null)
                }
                !Shizuku.pingBinder() -> {
                    tvStatus.text = "⚠ No root or Shizuku — one required"
                    tvStatus.setTextColor(getColor(R.color.error))
                }
                Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> {
                    tvStatus.text = "⚠ Tap to grant Shizuku permission"
                    tvStatus.setTextColor(getColor(R.color.error))
                    tvStatus.setOnClickListener { Shizuku.requestPermission(SHIZUKU_CODE) }
                }
                else -> {
                    tvStatus.text = "✓ Shizuku ready"
                    tvStatus.setTextColor(getColor(R.color.success))
                    tvStatus.setOnClickListener(null)
                }
            }
        } catch (e: Exception) {
            tvStatus.text = if (hasRoot) "✓ Root ready" else "⚠ No root or Shizuku"
            tvStatus.setTextColor(if (hasRoot) getColor(R.color.success) else getColor(R.color.error))
        }
    }

    // ── Shell command execution ────────────────────────────────────────────

    private fun runCommand(cmd: String): Boolean {
        // Shizuku path first (non-rooted users)
        if (shizukuReady()) {
            try {
                val process = Runtime.getRuntime().exec(
                    arrayOf("sh", "-c",
                        "echo '${cmd.replace("'", "'\\''")}' | " +
                        "CLASSPATH=/data/user/0/moe.shizuku.privileged.api/files/rish " +
                        "app_process /data/user/0/moe.shizuku.privileged.api/files rish.dummy --server"
                    )
                )
                if (process.waitFor() == 0) return true
            } catch (e: Exception) {
                Log.w("ColorTuner", "Shizuku failed: ${e.message}")
            }
        }
        // su fallback (rooted)
        return try {
            Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)).waitFor() == 0
        } catch (e: Exception) {
            Log.e("ColorTuner", "su failed: $cmd", e)
            false
        }
    }

    // ── Apply ─────────────────────────────────────────────────────────────

    private fun applySettings() {
        if (!rootReady()) { snack("No root or Shizuku available"); return }

        val kelvin  = progressToKelvin(seekTemp.progress)
        val sat     = seekSat.progress
        val gamma   = progressToGamma(seekGamma.progress)
        val red     = seekRed.progress / 100f
        val green   = seekGreen.progress / 100f
        val blue    = seekBlue.progress / 100f

        Thread {
            var ok = true

            // Temperature: only activate night display if below neutral
            if (kelvin < TEMP_MAX) {
                ok = ok && runCommand("settings put secure night_display_color_temperature $kelvin")
                ok = ok && runCommand("settings put secure night_display_activated 1")
            } else {
                ok = ok && runCommand("settings put secure night_display_activated 0")
                runCommand("settings delete secure night_display_color_temperature")
            }

            // Saturation
            ok = ok && runCommand("cmd color_display set-saturation $sat")

            // Gamma + RGB via SurfaceFlinger color matrix
            // Apply gamma correction and RGB scaling together as one 4x4 matrix
            // Gamma is applied per-channel as a power curve approximated linearly:
            // we encode it as a diagonal matrix scale (approximate for small deviations)
            // For real gamma, we use the service call with adjusted diagonal values.
            val rg = red   * gammaScale(gamma)
            val gg = green * gammaScale(gamma)
            val bg = blue  * gammaScale(gamma)
            val matrix = buildColorMatrix(rg, gg, bg)
            ok = ok && runCommand(buildSFCommand(matrix))

            val success = ok
            handler.post {
                snack(if (success) "Applied ✓" else "Some commands failed — check root/Shizuku")
                saveSliders()
            }
        }.start()
    }

    // ── Reset ─────────────────────────────────────────────────────────────

    private fun resetSettings() {
        if (!rootReady()) { snack("No root or Shizuku available"); return }

        Thread {
            runCommand("settings put secure night_display_activated 0")
            runCommand("settings delete secure night_display_color_temperature")
            runCommand("cmd color_display set-saturation 100")
            runCommand(buildSFCommand(buildColorMatrix(1f, 1f, 1f))) // identity

            handler.post {
                seekTemp.progress  = 100; etTempValue.setText("6500 K")
                seekSat.progress   = 100; etSatValue.setText("100")
                seekGamma.progress = gammaToProgress(1f); etGammaValue.setText("1.00")
                seekRed.progress   = 100; etRedValue.setText("100")
                seekGreen.progress = 100; etGreenValue.setText("100")
                seekBlue.progress  = 100; etBlueValue.setText("100")
                snack("Reset to defaults ✓")
                saveSliders()
            }
        }.start()
    }

    // ── Color matrix helpers ───────────────────────────────────────────────

    // Simple gamma approximation: midtone scale factor
    // For a proper gamma curve we'd need a LUT, but SurfaceFlinger's matrix
    // is linear — this scales the overall luminance response.
    private fun gammaScale(gamma: Float): Float {
        // Map gamma to a brightness multiplier: gamma=1.0 → 1.0, gamma>1 → darker, gamma<1 → brighter
        return (1f / gamma).coerceIn(0.1f, 2f)
    }

    private fun buildColorMatrix(r: Float, g: Float, b: Float): FloatArray {
        // 4x4 diagonal matrix, column-major for SurfaceFlinger
        return floatArrayOf(
            r,   0f,  0f,  0f,
            0f,  g,   0f,  0f,
            0f,  0f,  b,   0f,
            0f,  0f,  0f,  1f
        )
    }

    private fun buildSFCommand(matrix: FloatArray): String {
        val args = matrix.joinToString(" ") { f ->
            val bits = java.lang.Float.floatToIntBits(f)
            "i32 0x${Integer.toHexString(bits).padStart(8, '0')}"
        }
        return "service call SurfaceFlinger 1015 $args"
    }

    // ── Profiles ──────────────────────────────────────────────────────────

    data class Profile(
        val name: String,
        val kelvin: Int, val sat: Int,
        val gamma: Float,
        val red: Int, val green: Int, val blue: Int
    )

    private fun loadProfiles(): List<Profile> {
        val json = prefs.getString("profiles", "[]") ?: "[]"
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Profile(
                    o.getString("name"),
                    o.getInt("kelvin"), o.getInt("sat"),
                    o.optDouble("gamma", 1.0).toFloat(),
                    o.optInt("red", 100), o.optInt("green", 100), o.optInt("blue", 100)
                )
            }
        } catch (e: Exception) { emptyList() }
    }

    private fun saveProfiles(profiles: List<Profile>) {
        val arr = JSONArray()
        profiles.forEach {
            arr.put(JSONObject().apply {
                put("name", it.name); put("kelvin", it.kelvin); put("sat", it.sat)
                put("gamma", it.gamma.toDouble())
                put("red", it.red); put("green", it.green); put("blue", it.blue)
            })
        }
        prefs.edit().putString("profiles", arr.toString()).apply()
    }

    private fun saveProfile() {
        val name = etProfileName.text.toString().trim()
        if (name.isEmpty()) { snack("Enter a profile name"); return }
        val p = Profile(
            name,
            progressToKelvin(seekTemp.progress), seekSat.progress,
            progressToGamma(seekGamma.progress),
            seekRed.progress, seekGreen.progress, seekBlue.progress
        )
        val list = loadProfiles().toMutableList()
        list.removeAll { it.name == name }
        list.add(p)
        saveProfiles(list)
        etProfileName.text.clear()
        renderProfiles()
        snack("Saved \"$name\"")
    }

    private val builtins = listOf(
        Profile("Neutral",    6500, 100, 1.0f, 100, 100, 100),
        Profile("Night Warm", 3200,  80, 1.1f, 100,  95,  85),
        Profile("Vivid",      5500, 100, 0.9f, 100, 100, 100),
        Profile("Reading",    3800,  75, 1.2f, 100,  95,  80),
    )

    private fun renderProfiles() {
        layoutProfiles.removeAllViews()
        (builtins + loadProfiles()).forEach { profile ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, 4, 0, 4)
            }
            val btn = MaterialButton(this, null, com.google.android.material.R.attr.borderlessButtonStyle).apply {
                text = "${profile.name}  ${profile.kelvin}K  sat${profile.sat}  \u03b3${"%.1f".format(profile.gamma)}"
                textSize = 12f
                setTextColor(getColor(R.color.text_primary))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { loadProfile(profile) }
            }
            row.addView(btn)
            if (builtins.none { it.name == profile.name }) {
                val del = MaterialButton(this, null, com.google.android.material.R.attr.borderlessButtonStyle).apply {
                    text = "\u2715"
                    textSize = 12f
                    setTextColor(getColor(R.color.error))
                    setOnClickListener {
                        saveProfiles(loadProfiles().filter { it.name != profile.name })
                        renderProfiles()
                    }
                }
                row.addView(del)
            }
            layoutProfiles.addView(row)
        }
    }

    private fun loadProfile(p: Profile) {
        seekTemp.progress  = kelvinToProgress(p.kelvin)
        seekSat.progress   = p.sat
        seekGamma.progress = gammaToProgress(p.gamma)
        seekRed.progress   = p.red
        seekGreen.progress = p.green
        seekBlue.progress  = p.blue
        snack("Loaded \"${p.name}\" - tap Apply")
    }

    // ── Persist ───────────────────────────────────────────────────────────

    private fun saveSliders() {
        prefs.edit()
            .putInt("seekTemp", seekTemp.progress)
            .putInt("seekSat",  seekSat.progress)
            .putInt("seekGamma", seekGamma.progress)
            .putInt("seekRed",   seekRed.progress)
            .putInt("seekGreen", seekGreen.progress)
            .putInt("seekBlue",  seekBlue.progress)
            .apply()
    }

    private fun restoreSliders() {
        seekTemp.progress  = prefs.getInt("seekTemp",  100)
        seekSat.progress   = prefs.getInt("seekSat",   100)
        seekGamma.progress = prefs.getInt("seekGamma", gammaToProgress(1f))
        seekRed.progress   = prefs.getInt("seekRed",   100)
        seekGreen.progress = prefs.getInt("seekGreen", 100)
        seekBlue.progress  = prefs.getInt("seekBlue",  100)
        // EditTexts are updated by the SeekBar listeners firing on progress set
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private fun rootReady() = shizukuReady() || try {
        Runtime.getRuntime().exec(arrayOf("su", "-c", "true")).waitFor() == 0
    } catch (e: Exception) { false }

    private fun shizukuReady() = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Exception) { false }

    private fun snack(msg: String) =
        Snackbar.make(findViewById(android.R.id.content), msg, Snackbar.LENGTH_SHORT).show()
}
