package com.colortuner

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.snackbar.Snackbar
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    // ── Views ──────────────────────────────────────────────────────────────
    private lateinit var tvStatus: TextView
    private lateinit var seekTemp: SeekBar;  private lateinit var etTempValue: EditText
    private lateinit var seekSat: SeekBar;   private lateinit var etSatValue: EditText
    private lateinit var layoutProfiles: LinearLayout
    private lateinit var etProfileName: EditText
    private lateinit var btnSave: MaterialButton
    private lateinit var btnReset: MaterialButton
    private lateinit var btnService: MaterialButton
    private lateinit var scrollRoot: ScrollView

    private lateinit var prefs: SharedPreferences
    private var updatingFromSlider = false
    private var updatingFromEdit   = false

    private val TEMP_MIN = 1000; private val TEMP_MAX = 10000

    // Debounce live updates
    private val updateHandler = Handler(Looper.getMainLooper())
    private val updateRunnable = Runnable {
        saveSliders()
        if (prefs.getBoolean("serviceEnabled", false)) {
            ColorService.update(this)
        }
    }

    // ── Broadcast receiver for notification Stop ───────────────────────────
    // Catches Stop tap while app is in foreground.
    // onResume() catches it when app returns from background.
    private val serviceStoppedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == ColorService.BROADCAST_STOPPED) {
                updateServiceButton()
            }
        }
    }

    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startService() else snack("Notification permission needed")
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("colortuner", Context.MODE_PRIVATE)

        bindViews()
        setupSliders()
        scrollRoot.setOnTouchListener { _, _ ->
            dismissKeyboard(currentFocus ?: scrollRoot); false
        }

        btnReset.setOnClickListener   { resetAll() }
        btnSave.setOnClickListener    { saveProfile() }
        btnService.setOnClickListener { toggleService() }

        restoreSliders()
        updateStatus()
        renderProfiles()
    }

    override fun onResume() {
        super.onResume()
        // Re-read prefs — service writes serviceEnabled=false on stop,
        // so this catches notification Stop even when app was in background.
        updateServiceButton()

        val filter = IntentFilter(ColorService.BROADCAST_STOPPED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(serviceStoppedReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(serviceStoppedReceiver, filter)
        }
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(serviceStoppedReceiver) } catch (e: Exception) { }
    }

    // ── View binding ──────────────────────────────────────────────────────

    private fun bindViews() {
        scrollRoot     = findViewById(R.id.scrollRoot)
        tvStatus       = findViewById(R.id.tvStatus)
        seekTemp       = findViewById(R.id.seekTemp);  etTempValue = findViewById(R.id.etTempValue)
        seekSat        = findViewById(R.id.seekSat);   etSatValue  = findViewById(R.id.etSatValue)
        layoutProfiles = findViewById(R.id.layoutProfiles)
        etProfileName  = findViewById(R.id.etProfileName)
        btnSave        = findViewById(R.id.btnSave)
        btnReset       = findViewById(R.id.btnReset)
        btnService     = findViewById(R.id.btnService)
    }

    // ── Sliders ───────────────────────────────────────────────────────────

    private fun setupSliders() {
        linkSlider(seekTemp, etTempValue,
            toDisplay = { p -> "${progressToKelvin(p)}" },
            fromText  = { t -> kelvinToProgress(t.trim().toIntOrNull() ?: 6500) })
        linkSlider(seekSat, etSatValue,
            toDisplay = { p -> "$p" },
            fromText  = { t -> t.trim().toIntOrNull()?.coerceIn(0, 100) ?: 100 })
    }

    private fun linkSlider(seek: SeekBar, et: EditText,
                           toDisplay: (Int) -> String, fromText: (String) -> Int) {
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (updatingFromEdit) return
                updatingFromSlider = true
                et.setText(toDisplay(p))
                et.setSelection(et.text.length)
                updatingFromSlider = false
                if (fromUser) scheduleUpdate()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) { dismissKeyboard(sb) }
        })
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {
                if (updatingFromSlider) return
                updatingFromEdit = true
                seek.progress = fromText(s.toString())
                updatingFromEdit = false
                scheduleUpdate()
            }
            override fun beforeTextChanged(s: CharSequence, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence, a: Int, b: Int, c: Int) {}
        })
        et.setOnEditorActionListener { _, _, _ -> dismissKeyboard(et); true }
    }

    private fun scheduleUpdate() {
        updateHandler.removeCallbacks(updateRunnable)
        updateHandler.postDelayed(updateRunnable, 300)
    }

    // ── Conversions — use floating point to avoid rounding errors ─────────

    // Temperature slider has max=9000, so progress = kelvin - 1000 exactly (1K per step)
    private fun progressToKelvin(p: Int): Int = TEMP_MIN + p
    private fun kelvinToProgress(k: Int): Int = (k - TEMP_MIN).coerceIn(0, TEMP_MAX - TEMP_MIN)

    // ── Status ────────────────────────────────────────────────────────────

    private fun updateStatus() {
        tvStatus.text = "Temperature via dwb-set-cct  •  Saturation via ColorDisplayManager"
        tvStatus.setTextColor(getColor(R.color.text_muted))
    }

    // ── Reset ─────────────────────────────────────────────────────────────

    private fun resetAll() {
        dismissKeyboard(currentFocus ?: btnReset)
        seekTemp.progress = kelvinToProgress(6500)
        seekSat.progress  = 100
        saveSliders()
        if (prefs.getBoolean("serviceEnabled", false)) ColorService.update(this)
        snack("Reset to defaults ✓")
    }

    // ── Persist ───────────────────────────────────────────────────────────

    private fun saveSliders() {
        prefs.edit()
            .putInt("kelvin",  progressToKelvin(seekTemp.progress))
            .putInt("seekSat", seekSat.progress)
            .apply()
    }

    private fun restoreSliders() {
        seekTemp.progress = kelvinToProgress(prefs.getInt("kelvin", 6500))
        seekSat.progress  = prefs.getInt("seekSat", 100)
    }

    // ── Service toggle ────────────────────────────────────────────────────

    private fun toggleService() {
        val enabled = prefs.getBoolean("serviceEnabled", false)
        if (enabled) {
            // Update prefs and button immediately — don't wait for broadcast
            prefs.edit().putBoolean("serviceEnabled", false).apply()
            ColorService.stop(this)
            updateServiceButton()
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
            startService()
        }
    }

    private fun startService() {
        saveSliders()
        prefs.edit().putBoolean("serviceEnabled", true).apply()
        ColorService.start(this)
        updateServiceButton()
    }

    private fun updateServiceButton() {
        // Always read from prefs — service writes false there on any stop path
        val enabled = prefs.getBoolean("serviceEnabled", false)
        btnService.text = if (enabled) "■  Stop Color Service" else "▶  Start Color Service"
        btnService.setTextColor(
            if (enabled) getColor(R.color.error) else getColor(R.color.text_primary))
    }

    // ── Profiles ──────────────────────────────────────────────────────────

    data class Profile(val name: String, val kelvin: Int, val sat: Int)

    private val builtins = listOf(
        Profile("Neutral",    6500, 100),
        Profile("Night Warm", 3200,  80),
        Profile("Vivid",      6500, 100),
        Profile("Reading",    3800,  75),
        Profile("Cool",       8000, 100),
    )

    private fun loadProfiles(): List<Profile> {
        return try {
            val arr = JSONArray(prefs.getString("profiles", "[]") ?: "[]")
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Profile(o.getString("name"), o.getInt("kelvin"), o.getInt("sat"))
            }
        } catch (e: Exception) { emptyList() }
    }

    private fun saveProfiles(profiles: List<Profile>) {
        val arr = JSONArray()
        profiles.forEach { arr.put(JSONObject().apply {
            put("name", it.name); put("kelvin", it.kelvin); put("sat", it.sat)
        })}
        prefs.edit().putString("profiles", arr.toString()).apply()
    }

    private fun saveProfile() {
        val name = etProfileName.text.toString().trim()
        if (name.isEmpty()) { snack("Enter a profile name"); return }
        dismissKeyboard(etProfileName)
        val p = Profile(name, progressToKelvin(seekTemp.progress), seekSat.progress)
        val list = loadProfiles().toMutableList()
        list.removeAll { it.name == name }
        list.add(p)
        saveProfiles(list)
        etProfileName.text.clear()
        renderProfiles()
        snack("Saved \"$name\"")
    }

    private fun renderProfiles() {
        layoutProfiles.removeAllViews()
        (builtins + loadProfiles()).forEach { profile ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, 4, 0, 4)
            }
            val btn = MaterialButton(this, null,
                com.google.android.material.R.attr.borderlessButtonStyle).apply {
                text = "${profile.name}  •  ${profile.kelvin}K  •  sat ${profile.sat}"
                textSize = 12f
                setTextColor(getColor(R.color.text_primary))
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { loadProfile(profile) }
            }
            row.addView(btn)
            if (builtins.none { it.name == profile.name }) {
                val del = MaterialButton(this, null,
                    com.google.android.material.R.attr.borderlessButtonStyle).apply {
                    text = "\u2715"; textSize = 12f
                    setTextColor(getColor(R.color.error))
                    setOnClickListener {
                        saveProfiles(loadProfiles().filter { it.name != profile.name })
                        renderProfiles()
                    }
                }
                row.addView(del)
            }
            layoutProfiles.addView(row)
        }
    }

    private fun loadProfile(p: Profile) {
        seekTemp.progress = kelvinToProgress(p.kelvin)
        seekSat.progress  = p.sat
        snack("Loaded \"${p.name}\"")
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private fun dismissKeyboard(view: android.view.View) {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(view.windowToken, 0)
        view.clearFocus()
    }

    private fun snack(msg: String) =
        Snackbar.make(findViewById(android.R.id.content), msg, Snackbar.LENGTH_SHORT).show()
}
