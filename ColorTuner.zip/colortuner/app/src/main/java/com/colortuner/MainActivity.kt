package com.colortuner

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.snackbar.Snackbar
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    // ── Views ──────────────────────────────────────────────────────────────
    private lateinit var tvStatus: TextView
    private lateinit var btnTempMode: MaterialButton
    private lateinit var seekTemp: SeekBar;  private lateinit var etTempValue: EditText
    private lateinit var seekSat: SeekBar;   private lateinit var etSatValue: EditText
    private lateinit var layoutProfiles: LinearLayout
    private lateinit var etProfileName: EditText
    private lateinit var btnSave: MaterialButton
    private lateinit var btnApply: MaterialButton
    private lateinit var btnReset: MaterialButton
    private lateinit var btnWatchdog: MaterialButton
    private lateinit var scrollRoot: ScrollView

    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    // Temperature mode: "night" = night display pipeline, "dwb" = display white balance
    private var tempMode = "night"

    private var updatingFromSlider = false
    private var updatingFromEdit = false

    private val TEMP_MIN = 3000; private val TEMP_MAX = 8000
    private val SHIZUKU_CODE = 1001

    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { code, _ ->
        if (code == SHIZUKU_CODE) handler.post { updateStatus() }
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("colortuner", Context.MODE_PRIVATE)
        tempMode = prefs.getString("tempMode", "night") ?: "night"

        bindViews()

        linkSlider(seekTemp, etTempValue,
            toDisplay = { p -> "${progressToKelvin(p)}" },
            fromText  = { t -> kelvinToProgress(t.trim().toIntOrNull() ?: TEMP_MAX) })
        linkSlider(seekSat, etSatValue,
            toDisplay = { p -> "$p" },
            fromText  = { t -> t.trim().toIntOrNull()?.coerceIn(0, 100) ?: 100 })

        // Dismiss keyboard when Done is pressed on any EditText
        listOf(etTempValue, etSatValue, etProfileName).forEach { et ->
            et.setOnEditorActionListener { _, _, _ ->
                dismissKeyboard(et)
                true
            }
        }

        // Dismiss keyboard when scrolling
        scrollRoot.setOnTouchListener { _, _ ->
            dismissKeyboard(currentFocus ?: scrollRoot)
            false
        }

        btnTempMode.setOnClickListener { toggleTempMode() }
        btnApply.setOnClickListener    { applySettings() }
        btnReset.setOnClickListener    { resetSettings() }
        btnSave.setOnClickListener     { saveProfile() }
        btnWatchdog.setOnClickListener { toggleWatchdog() }

        Shizuku.addRequestPermissionResultListener(shizukuListener)
        restoreSliders()
        updateTempModeButton()
        updateWatchdogButton()
        updateStatus()
        renderProfiles()
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(shizukuListener)
    }

    // ── View binding ──────────────────────────────────────────────────────

    private fun bindViews() {
        scrollRoot     = findViewById(R.id.scrollRoot)
        tvStatus       = findViewById(R.id.tvStatus)
        btnTempMode    = findViewById(R.id.btnTempMode)
        seekTemp       = findViewById(R.id.seekTemp);  etTempValue = findViewById(R.id.etTempValue)
        seekSat        = findViewById(R.id.seekSat);   etSatValue  = findViewById(R.id.etSatValue)
        layoutProfiles = findViewById(R.id.layoutProfiles)
        etProfileName  = findViewById(R.id.etProfileName)
        btnSave        = findViewById(R.id.btnSave)
        btnApply       = findViewById(R.id.btnApply)
        btnReset       = findViewById(R.id.btnReset)
        btnWatchdog    = findViewById(R.id.btnWatchdog)
    }

    // ── Keyboard dismissal ────────────────────────────────────────────────

    private fun dismissKeyboard(view: android.view.View) {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(view.windowToken, 0)
        view.clearFocus()
    }

    // ── Slider <-> EditText two-way binding ───────────────────────────────

    private fun linkSlider(
        seek: SeekBar, et: EditText,
        toDisplay: (Int) -> String,
        fromText: (String) -> Int
    ) {
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (updatingFromEdit) return
                updatingFromSlider = true
                et.setText(toDisplay(p))
                et.setSelection(et.text.length)
                updatingFromSlider = false
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                dismissKeyboard(sb)
            }
        })
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {
                if (updatingFromSlider) return
                updatingFromEdit = true
                seek.progress = fromText(s.toString())
                updatingFromEdit = false
            }
            override fun beforeTextChanged(s: CharSequence, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence, a: Int, b: Int, c: Int) {}
        })
    }

    // ── Temperature mode toggle ───────────────────────────────────────────

    private fun toggleTempMode() {
        tempMode = if (tempMode == "night") "dwb" else "night"
        prefs.edit().putString("tempMode", tempMode).apply()
        updateTempModeButton()
    }

    private fun updateTempModeButton() {
        btnTempMode.text = if (tempMode == "night") "Night Display" else "White Balance"
    }

    // ── Conversions ───────────────────────────────────────────────────────

    private fun progressToKelvin(p: Int) = TEMP_MIN + p * (TEMP_MAX - TEMP_MIN) / 100
    private fun kelvinToProgress(k: Int) = ((k - TEMP_MIN) * 100 / (TEMP_MAX - TEMP_MIN)).coerceIn(0, 100)

    // ── Status ────────────────────────────────────────────────────────────

    private fun updateStatus() {
        val hasRoot = try {
            Runtime.getRuntime().exec(arrayOf("su", "-c", "true")).waitFor() == 0
        } catch (e: Exception) { false }

        try {
            when {
                hasRoot -> {
                    val shizuku = try {
                        Shizuku.pingBinder() &&
                        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                    } catch (e: Exception) { false }
                    tvStatus.text = if (shizuku) "✓ Root + Shizuku ready" else "✓ Root ready"
                    tvStatus.setTextColor(getColor(R.color.success))
                    tvStatus.setOnClickListener(null)
                }
                !Shizuku.pingBinder() -> {
                    tvStatus.text = "⚠ No root or Shizuku — one required"
                    tvStatus.setTextColor(getColor(R.color.error))
                }
                Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> {
                    tvStatus.text = "⚠ Tap to grant Shizuku permission"
                    tvStatus.setTextColor(getColor(R.color.error))
                    tvStatus.setOnClickListener { Shizuku.requestPermission(SHIZUKU_CODE) }
                }
                else -> {
                    tvStatus.text = "✓ Shizuku ready"
                    tvStatus.setTextColor(getColor(R.color.success))
                    tvStatus.setOnClickListener(null)
                }
            }
        } catch (e: Exception) {
            tvStatus.text = if (hasRoot) "✓ Root ready" else "⚠ No root or Shizuku"
            tvStatus.setTextColor(if (hasRoot) getColor(R.color.success) else getColor(R.color.error))
        }
    }

    // ── Shell command execution ────────────────────────────────────────────

    private fun runCommand(cmd: String): Boolean {
        if (shizukuReady()) {
            try {
                val process = Runtime.getRuntime().exec(
                    arrayOf("sh", "-c",
                        "echo '${cmd.replace("'", "'\\''")}' | " +
                        "CLASSPATH=/data/user/0/moe.shizuku.privileged.api/files/rish " +
                        "app_process /data/user/0/moe.shizuku.privileged.api/files rish.dummy --server"
                    )
                )
                if (process.waitFor() == 0) return true
            } catch (e: Exception) {
                Log.w("ColorTuner", "Shizuku failed: ${e.message}")
            }
        }
        return try {
            Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)).waitFor() == 0
        } catch (e: Exception) {
            Log.e("ColorTuner", "su failed: $cmd", e)
            false
        }
    }

    // ── Apply ─────────────────────────────────────────────────────────────

    private fun applySettings() {
        if (!rootReady()) { snack("No root or Shizuku available"); return }
        dismissKeyboard(currentFocus ?: btnApply)
        saveSliders() // persist before service reads

        val kelvin = progressToKelvin(seekTemp.progress)
        val sat    = seekSat.progress

        Thread {
            var ok = true

            // Temperature
            when (tempMode) {
                "night" -> {
                    if (kelvin < 6500) {
                        ok = ok && runCommand("settings put secure night_display_color_temperature $kelvin")
                        ok = ok && runCommand("settings put secure night_display_activated 1")
                    } else {
                        runCommand("settings put secure night_display_activated 0")
                        runCommand("settings delete secure night_display_color_temperature")
                    }
                    // Always disable dwb when using night mode
                    runCommand("cmd display dwb-set-cct -1")
                }
                "dwb" -> {
                    // Display white balance — separate hardware pipeline
                    // -1 disables, otherwise pass CCT in Kelvin
                    runCommand("settings put secure night_display_activated 0")
                    ok = ok && runCommand("cmd display dwb-set-cct $kelvin")
                }
            }

            // Saturation
            ok = ok && runCommand("cmd color_display set-saturation $sat")

            val success = ok
            handler.post {
                snack(if (success) "Applied ✓" else "Some commands failed")
                saveSliders()
            }
        }.start()
    }

    // ── Reset ─────────────────────────────────────────────────────────────

    private fun resetSettings() {
        if (!rootReady()) { snack("No root or Shizuku available"); return }
        dismissKeyboard(currentFocus ?: btnReset)

        Thread {
            runCommand("settings put secure night_display_activated 0")
            runCommand("settings delete secure night_display_color_temperature")
            runCommand("cmd display dwb-set-cct -1")
            runCommand("cmd color_display set-saturation 100")

            handler.post {
                seekTemp.progress = 100
                seekSat.progress  = 100
                snack("Reset to defaults ✓")
                saveSliders()
            }
        }.start()
    }

    // ── Profiles ──────────────────────────────────────────────────────────

    data class Profile(val name: String, val kelvin: Int, val sat: Int, val tempMode: String)

    private val builtins = listOf(
        Profile("Neutral",    6500, 100, "dwb"),
        Profile("Night Warm", 3200,  80, "night"),
        Profile("Vivid",      5500, 100, "night"),
        Profile("Reading",    3800,  75, "night"),
    )

    private fun loadProfiles(): List<Profile> {
        val json = prefs.getString("profiles", "[]") ?: "[]"
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Profile(
                    o.getString("name"),
                    o.getInt("kelvin"),
                    o.getInt("sat"),
                    o.optString("tempMode", "night")
                )
            }
        } catch (e: Exception) { emptyList() }
    }

    private fun saveProfiles(profiles: List<Profile>) {
        val arr = JSONArray()
        profiles.forEach {
            arr.put(JSONObject().apply {
                put("name", it.name)
                put("kelvin", it.kelvin)
                put("sat", it.sat)
                put("tempMode", it.tempMode)
            })
        }
        prefs.edit().putString("profiles", arr.toString()).apply()
    }

    private fun saveProfile() {
        val name = etProfileName.text.toString().trim()
        if (name.isEmpty()) { snack("Enter a profile name"); return }
        dismissKeyboard(etProfileName)
        val p = Profile(name, progressToKelvin(seekTemp.progress), seekSat.progress, tempMode)
        val list = loadProfiles().toMutableList()
        list.removeAll { it.name == name }
        list.add(p)
        saveProfiles(list)
        etProfileName.text.clear()
        renderProfiles()
        snack("Saved \"$name\"")
    }

    private fun renderProfiles() {
        layoutProfiles.removeAllViews()
        (builtins + loadProfiles()).forEach { profile ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, 4, 0, 4)
            }
            val label = "${profile.name}  •  ${profile.kelvin}K  •  sat ${profile.sat}"
            val btn = MaterialButton(this, null, com.google.android.material.R.attr.borderlessButtonStyle).apply {
                text = label
                textSize = 12f
                setTextColor(getColor(R.color.text_primary))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { loadProfile(profile) }
            }
            row.addView(btn)
            if (builtins.none { it.name == profile.name }) {
                val del = MaterialButton(this, null, com.google.android.material.R.attr.borderlessButtonStyle).apply {
                    text = "\u2715"
                    textSize = 12f
                    setTextColor(getColor(R.color.error))
                    setOnClickListener {
                        saveProfiles(loadProfiles().filter { it.name != profile.name })
                        renderProfiles()
                    }
                }
                row.addView(del)
            }
            layoutProfiles.addView(row)
        }
    }

    private fun loadProfile(p: Profile) {
        seekTemp.progress = kelvinToProgress(p.kelvin)
        seekSat.progress  = p.sat
        tempMode = p.tempMode
        updateTempModeButton()
        snack("Loaded \"${p.name}\" - tap Apply")
    }

    // ── Persist ───────────────────────────────────────────────────────────

    private fun saveSliders() {
        prefs.edit()
            .putInt("seekTemp", seekTemp.progress)
            .putInt("seekSat",  seekSat.progress)
            .apply()
    }

    private fun restoreSliders() {
        seekTemp.progress = prefs.getInt("seekTemp", 100)
        seekSat.progress  = prefs.getInt("seekSat",  100)
    }

    // ── Watchdog ──────────────────────────────────────────────────────────

    private fun toggleWatchdog() {
        val enabled = prefs.getBoolean("watchdogEnabled", false)
        if (enabled) {
            WatchdogService.stop(this)
            prefs.edit().putBoolean("watchdogEnabled", false).apply()
        } else {
            saveSliders() // ensure latest values are saved before service reads them
            WatchdogService.start(this)
            prefs.edit().putBoolean("watchdogEnabled", true).apply()
        }
        updateWatchdogButton()
    }

    private fun updateWatchdogButton() {
        val enabled = prefs.getBoolean("watchdogEnabled", false)
        if (enabled) {
            btnWatchdog.text = "■  Stop Watchdog"
            btnWatchdog.setBackgroundColor(getColor(R.color.surface_alt))
            btnWatchdog.setTextColor(getColor(R.color.error))
        } else {
            btnWatchdog.text = "▶  Start Watchdog"
            btnWatchdog.setTextColor(getColor(R.color.text_primary))
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private fun rootReady() = shizukuReady() || try {
        Runtime.getRuntime().exec(arrayOf("su", "-c", "true")).waitFor() == 0
    } catch (e: Exception) { false }

    private fun shizukuReady() = try {
        Shizuku.pingBinder() &&
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Exception) { false }

    private fun snack(msg: String) =
        Snackbar.make(findViewById(android.R.id.content), msg, Snackbar.LENGTH_SHORT).show()
}
