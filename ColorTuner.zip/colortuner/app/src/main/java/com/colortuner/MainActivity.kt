package com.colortuner

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.switchmaterial.SwitchMaterial
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    // ── Views ──────────────────────────────────────────────────────────────
    private lateinit var tvStatus: TextView
    private lateinit var tvTempValue: TextView
    private lateinit var tvSatValue: TextView
    private lateinit var seekTemp: SeekBar
    private lateinit var seekSat: SeekBar
    private lateinit var switchTemp: SwitchMaterial
    private lateinit var layoutProfiles: LinearLayout
    private lateinit var etProfileName: EditText
    private lateinit var btnSave: MaterialButton
    private lateinit var btnApply: MaterialButton
    private lateinit var btnReset: MaterialButton

    // ── State ──────────────────────────────────────────────────────────────
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    // Temperature range
    private val TEMP_MIN = 3000
    private val TEMP_MAX = 6500

    // ── Shizuku permission request code ───────────────────────────────────
    private val SHIZUKU_CODE = 1001

    private val shizukuRequestListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_CODE) {
                updateStatus()
            }
        }

    // ── Lifecycle ──────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("colortuner", Context.MODE_PRIVATE)

        bindViews()
        setupSliders()
        setupButtons()
        restoreSliders()

        Shizuku.addRequestPermissionResultListener(shizukuRequestListener)
        updateStatus()
        renderProfiles()
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(shizukuRequestListener)
    }

    // ── View binding ──────────────────────────────────────────────────────

    private fun bindViews() {
        tvStatus      = findViewById(R.id.tvStatus)
        tvTempValue   = findViewById(R.id.tvTempValue)
        tvSatValue    = findViewById(R.id.tvSatValue)
        seekTemp      = findViewById(R.id.seekTemp)
        seekSat       = findViewById(R.id.seekSat)
        switchTemp    = findViewById(R.id.switchTemp)
        layoutProfiles = findViewById(R.id.layoutProfiles)
        etProfileName = findViewById(R.id.etProfileName)
        btnSave       = findViewById(R.id.btnSave)
        btnApply      = findViewById(R.id.btnApply)
        btnReset      = findViewById(R.id.btnReset)
    }

    // ── Slider setup ──────────────────────────────────────────────────────

    private fun setupSliders() {
        seekTemp.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                tvTempValue.text = "${progressToKelvin(p)} K"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        seekSat.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                tvSatValue.text = "$p"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
    }

    private fun progressToKelvin(progress: Int): Int {
        // progress 0..100 → TEMP_MIN..TEMP_MAX
        return TEMP_MIN + (progress * (TEMP_MAX - TEMP_MIN) / 100)
    }

    private fun kelvinToProgress(kelvin: Int): Int {
        return ((kelvin - TEMP_MIN) * 100 / (TEMP_MAX - TEMP_MIN)).coerceIn(0, 100)
    }

    // ── Button setup ──────────────────────────────────────────────────────

    private fun setupButtons() {
        btnApply.setOnClickListener { applySettings() }
        btnReset.setOnClickListener { resetSettings() }
        btnSave.setOnClickListener { saveProfile() }
    }

    // ── Shizuku status ────────────────────────────────────────────────────

    private fun updateStatus() {
        // Check root first
        val hasRoot = try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            p.waitFor() == 0
        } catch (e: Exception) { false }

        try {
            when {
                hasRoot && !Shizuku.pingBinder() -> {
                    tvStatus.text = "✓ Root detected — ready (Shizuku optional)"
                    tvStatus.setTextColor(getColor(R.color.success))
                    tvStatus.setOnClickListener(null)
                }
                !Shizuku.pingBinder() -> {
                    tvStatus.text = "⚠ No root or Shizuku — start Shizuku or root device"
                    tvStatus.setTextColor(getColor(R.color.error))
                }
                Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> {
                    tvStatus.text = "⚠ Shizuku permission needed — tap to grant"
                    tvStatus.setTextColor(getColor(R.color.error))
                    tvStatus.setOnClickListener {
                        Shizuku.requestPermission(SHIZUKU_CODE)
                    }
                }
                else -> {
                    tvStatus.text = "✓ Shizuku connected — ready"
                    tvStatus.setTextColor(getColor(R.color.success))
                    tvStatus.setOnClickListener(null)
                }
            }
        } catch (e: Exception) {
            if (hasRoot) {
                tvStatus.text = "✓ Root detected — ready"
                tvStatus.setTextColor(getColor(R.color.success))
            } else {
                tvStatus.text = "⚠ No root or Shizuku found"
                tvStatus.setTextColor(getColor(R.color.error))
            }
        }
    }

    // ── Core: run a shell command ─────────────────────────────────────────
    //
    // Shizuku path: pipes command into rish (Shizuku's privileged shell),
    // runs as shell uid 2000 — has CONTROL_DISPLAY_COLOR_TRANSFORMS on
    // Android 12+. Works on non-rooted devices.
    //
    // su fallback: for rooted devices without Shizuku.

    private fun runCommand(cmd: String): Boolean {
        if (shizukuReady()) {
            try {
                // rish is Shizuku's built-in privileged shell
                val process = Runtime.getRuntime().exec(
                    arrayOf("sh", "-c",
                        "echo '${cmd.replace("'", "'\\''")}' | " +
                        "CLASSPATH=/data/user/0/moe.shizuku.privileged.api/files/rish " +
                        "app_process /data/user/0/moe.shizuku.privileged.api/files rish.dummy --server"
                    )
                )
                val exit = process.waitFor()
                Log.d("ColorTuner", "rish exit=$exit cmd=$cmd")
                if (exit == 0) return true
            } catch (e: Exception) {
                Log.w("ColorTuner", "rish failed, trying su: ${e.message}")
            }
        }

        // Fallback: su (rooted devices)
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val exit = process.waitFor()
            Log.d("ColorTuner", "su exit=$exit cmd=$cmd")
            exit == 0
        } catch (e: Exception) {
            Log.e("ColorTuner", "su failed: $cmd", e)
            false
        }
    }

    // ── Apply / Reset ─────────────────────────────────────────────────────

    private fun applySettings() {
        if (!shizukuReady()) {
            snack("Shizuku not ready")
            return
        }

        val kelvin = progressToKelvin(seekTemp.progress)
        val sat = seekSat.progress
        val tempEnabled = switchTemp.isChecked

        Thread {
            var ok = true

            // Temperature
            if (tempEnabled) {
                ok = ok && runCommand("settings put secure night_display_activated 1")
                ok = ok && runCommand("settings put secure night_display_color_temperature $kelvin")
            } else {
                ok = ok && runCommand("settings put secure night_display_activated 0")
            }

            // Saturation via ColorDisplayManager (setSaturationLevel)
            // sat 0..100 maps directly to the API's 0..100 range
            ok = ok && setSaturationLevel(sat)

            val success = ok
            handler.post {
                if (success) {
                    snack("Applied ✓")
                    saveSliders()
                } else {
                    snack("Some commands failed — check Shizuku permission")
                }
            }
        }.start()
    }

    private fun resetSettings() {
        if (!shizukuReady()) {
            snack("Shizuku not ready")
            return
        }

        Thread {
            runCommand("settings put secure night_display_activated 0")
            runCommand("settings delete secure night_display_color_temperature")
            setSaturationLevel(100)

            handler.post {
                seekTemp.progress = 100
                seekSat.progress = 100
                switchTemp.isChecked = false
                tvTempValue.text = "6500 K"
                tvSatValue.text = "100"
                snack("Reset to defaults ✓")
                saveSliders()
            }
        }.start()
    }

    // ── Saturation via ColorDisplayManager hidden API ─────────────────────
    //
    // ColorDisplayManager.setSaturationLevel(int) is a @hide API.
    // We call it via a privileged shell command using Shizuku, which runs
    // as the shell/root user and can invoke 'cmd color_display' or use
    // the settings provider.
    //
    // On Android 12+, the correct approach is:
    //   cmd color_display set-saturation-level <0-100>
    //
    // This is the shell interface to ColorDisplayManager.setSaturationLevel().

    private fun setSaturationLevel(level: Int): Boolean {
        // Primary: cmd color_display (Android 12+ shell command)
        val result = runCommand("cmd color_display set-saturation-level $level")
        if (result) return true

        // Fallback: write the secure setting directly (older builds)
        return runCommand("settings put secure display_color_mode_vendor_hint $level")
    }

    // ── Profiles ──────────────────────────────────────────────────────────

    data class Profile(val name: String, val kelvin: Int, val sat: Int, val tempEnabled: Boolean)

    private fun loadProfiles(): List<Profile> {
        val json = prefs.getString("profiles", "[]") ?: "[]"
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Profile(
                    o.getString("name"),
                    o.getInt("kelvin"),
                    o.getInt("sat"),
                    o.optBoolean("tempEnabled", true)
                )
            }
        } catch (e: Exception) { emptyList() }
    }

    private fun saveProfiles(profiles: List<Profile>) {
        val arr = JSONArray()
        profiles.forEach {
            arr.put(JSONObject().apply {
                put("name", it.name)
                put("kelvin", it.kelvin)
                put("sat", it.sat)
                put("tempEnabled", it.tempEnabled)
            })
        }
        prefs.edit().putString("profiles", arr.toString()).apply()
    }

    private fun saveProfile() {
        val name = etProfileName.text.toString().trim()
        if (name.isEmpty()) { snack("Enter a profile name"); return }

        val kelvin = progressToKelvin(seekTemp.progress)
        val sat = seekSat.progress
        val tempEnabled = switchTemp.isChecked

        val profiles = loadProfiles().toMutableList()
        profiles.removeAll { it.name == name }
        profiles.add(Profile(name, kelvin, sat, tempEnabled))
        saveProfiles(profiles)

        etProfileName.text.clear()
        renderProfiles()
        snack("Saved \"$name\"")
    }

    private fun renderProfiles() {
        layoutProfiles.removeAllViews()
        val profiles = loadProfiles()

        // Built-in presets
        val builtins = listOf(
            Profile("Neutral",    6500, 100, false),
            Profile("Night Warm", 3200, 80,  true),
            Profile("Vivid",      5500, 100, false),
            Profile("Reading",    3800, 70,  true),
        )

        (builtins + profiles).forEach { profile ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, 6, 0, 6)
            }

            val btn = MaterialButton(this, null, com.google.android.material.R.attr.borderlessButtonStyle).apply {
                text = "${profile.name}  •  ${profile.kelvin}K  •  sat ${profile.sat}"
                textSize = 13f
                setTextColor(getColor(R.color.text_primary))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { loadProfile(profile) }
            }
            row.addView(btn)

            // Delete button for user profiles only
            if (!builtins.any { it.name == profile.name }) {
                val del = MaterialButton(this, null, com.google.android.material.R.attr.borderlessButtonStyle).apply {
                    text = "✕"
                    textSize = 12f
                    setTextColor(getColor(R.color.error))
                    setOnClickListener {
                        val updated = loadProfiles().filter { it.name != profile.name }
                        saveProfiles(updated)
                        renderProfiles()
                    }
                }
                row.addView(del)
            }

            layoutProfiles.addView(row)
        }
    }

    private fun loadProfile(p: Profile) {
        seekTemp.progress = kelvinToProgress(p.kelvin)
        seekSat.progress = p.sat
        switchTemp.isChecked = p.tempEnabled
        tvTempValue.text = "${p.kelvin} K"
        tvSatValue.text = "${p.sat}"
        snack("Loaded \"${p.name}\" - tap Apply")
    }

    // ── Persist slider state ───────────────────────────────────────────────

    private fun saveSliders() {
        prefs.edit()
            .putInt("seekTemp", seekTemp.progress)
            .putInt("seekSat", seekSat.progress)
            .putBoolean("tempEnabled", switchTemp.isChecked)
            .apply()
    }

    private fun restoreSliders() {
        val t = prefs.getInt("seekTemp", 100)
        val s = prefs.getInt("seekSat", 100)
        val te = prefs.getBoolean("tempEnabled", false)
        seekTemp.progress = t
        seekSat.progress = s
        switchTemp.isChecked = te
        tvTempValue.text = "${progressToKelvin(t)} K"
        tvSatValue.text = "$s"
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private fun shizukuReady(): Boolean {
        return try {
            Shizuku.pingBinder() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) { false }
    }

    private fun snack(msg: String) {
        Snackbar.make(findViewById(android.R.id.content), msg, Snackbar.LENGTH_SHORT).show()
    }
}
